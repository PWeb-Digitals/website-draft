import { defineField, defineType } from 'sanity';

/** Portfolio items. Ready for the /work page to read from Sanity. */
export const project = defineType({
  name: 'project',
  title: 'Portfolio project',
  type: 'document',
  fields: [
    defineField({ name: 'title', type: 'string', validation: (r) => r.required() }),
    defineField({ name: 'slug', type: 'slug', options: { source: 'title' }, validation: (r) => r.required() }),
    defineField({ name: 'client', type: 'string' }),
    defineField({ name: 'liveUrl', title: 'Live site URL', type: 'url' }),
    defineField({ name: 'tags', type: 'array', of: [{ type: 'string' }], options: { layout: 'tags' }, description: 'e.g. Website, Booking, Store, Automation' }),
    defineField({ name: 'summary', type: 'text', rows: 3, validation: (r) => r.required().max(240) }),
    defineField({
      name: 'cover', type: 'image', options: { hotspot: true },
      fields: [{ name: 'alt', type: 'string', title: 'Alt text', validation: (r) => r.required() }],
    }),
    defineField({ name: 'gallery', type: 'array', of: [{ type: 'image', options: { hotspot: true }, fields: [{ name: 'alt', type: 'string', title: 'Alt text' }] }] }),
    defineField({ name: 'body', title: 'Case study', type: 'blockContent' }),
    defineField({ name: 'featured', type: 'boolean', initialValue: false, description: 'Show on the homepage' }),
    defineField({ name: 'order', type: 'number', description: 'Lower numbers show first' }),
  ],
  preview: { select: { title: 'title', subtitle: 'client', media: 'cover' } },
});
