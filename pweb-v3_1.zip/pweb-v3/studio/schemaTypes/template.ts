import { defineField, defineType } from 'sanity';

/** Industry templates shown on /templates and /templates/[slug]. Visitors view the demo, send a brief, then pay the deposit. */
export const template = defineType({
  name: 'template',
  title: 'Website template',
  type: 'document',
  fields: [
    defineField({ name: 'title', type: 'string', description: 'e.g. Restaurant', validation: (r) => r.required() }),
    defineField({
      name: 'slug', type: 'slug', options: { source: 'title' },
      description: 'The web address: pwebdigitals.com/templates/this-part. Don’t change it after publishing.',
      validation: (r) => r.required(),
    }),
    defineField({ name: 'summary', type: 'text', rows: 3, description: 'One or two sentences for the templates list.', validation: (r) => r.required().max(220) }),
    defineField({ name: 'features', type: 'array', of: [{ type: 'string' }], description: 'What the demo can do, e.g. Online ordering, Table booking' }),
    defineField({ name: 'demoUrl', title: 'Live demo URL', type: 'url' }),
    defineField({
      name: 'cover', type: 'image', options: { hotspot: true },
      fields: [{ name: 'alt', type: 'string', title: 'Alt text', validation: (r) => r.required() }],
    }),
    defineField({ name: 'priceLabel', title: 'Price shown', type: 'string', description: 'e.g. From ₦350,000 or From $400. Leave empty to show "Price on request".' }),
    defineField({
      name: 'paymentUrl', title: 'Paystack payment page URL', type: 'url',
      description: 'Create a Payment Page in your Paystack dashboard for the deposit and paste its link here. Visitors go there after sending their brief.',
    }),
    defineField({ name: 'order', type: 'number', description: 'Lower numbers show first' }),
  ],
  preview: { select: { title: 'title', subtitle: 'priceLabel', media: 'cover' } },
});
