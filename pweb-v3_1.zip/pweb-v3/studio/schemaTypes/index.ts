import { post } from './post';
import { project } from './project';
import { template } from './template';
import { blockContent } from './blockContent';

export const schemaTypes = [post, project, template, blockContent];
