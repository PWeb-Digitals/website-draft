import { defineField, defineType } from 'sanity';

export const post = defineType({
  name: 'post',
  title: 'Blog post',
  type: 'document',
  groups: [
    { name: 'content', title: 'Content', default: true },
    { name: 'seo', title: 'SEO' },
  ],
  fields: [
    defineField({ name: 'title', type: 'string', group: 'content', validation: (r) => r.required().max(110) }),
    defineField({
      name: 'slug', type: 'slug', group: 'content',
      description: 'The web address: pwebdigitals.com/blog/this-part. Click Generate. Don’t change it after publishing.',
      options: { source: 'title', maxLength: 90 },
      validation: (r) => r.required(),
    }),
    defineField({
      name: 'publishedAt', title: 'Publish date', type: 'datetime', group: 'content',
      description: 'The post goes live on the site at this time.',
      initialValue: () => new Date().toISOString(),
      validation: (r) => r.required(),
    }),
    defineField({
      name: 'category', type: 'string', group: 'content',
      options: { list: ['Web design', 'AI automation', 'CRM & follow-up', 'SEO', 'Case study', 'Business'] },
    }),
    defineField({
      name: 'excerpt', type: 'text', rows: 3, group: 'content',
      description: 'One or two sentences shown on the blog list.',
      validation: (r) => r.required().max(240),
    }),
    defineField({
      name: 'coverImage', type: 'image', group: 'content', options: { hotspot: true },
      fields: [{ name: 'alt', type: 'string', title: 'Alt text', validation: (r) => r.required() }],
    }),
    defineField({ name: 'body', type: 'blockContent', group: 'content' }),
    defineField({
      name: 'seoTitle', title: 'SEO title', type: 'string', group: 'seo',
      description: 'Optional. What Google shows as the headline. Leave empty to use the title. Aim for under 60 characters.',
      validation: (r) => r.max(70).warning('Google usually cuts titles after about 60 characters'),
    }),
    defineField({
      name: 'seoDescription', title: 'SEO description', type: 'text', rows: 3, group: 'seo',
      description: 'Optional. The grey text under the headline on Google. Leave empty to use the excerpt.',
      validation: (r) => r.max(170).warning('Google usually cuts descriptions after about 155 characters'),
    }),
  ],
  orderings: [{ title: 'Newest first', name: 'publishedDesc', by: [{ field: 'publishedAt', direction: 'desc' }] }],
  preview: {
    select: { title: 'title', date: 'publishedAt', media: 'coverImage' },
    prepare: ({ title, date, media }) => ({ title, subtitle: date ? new Date(date).toDateString() : 'No date', media }),
  },
});
