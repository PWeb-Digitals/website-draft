import { defineConfig } from 'sanity';
import { structureTool } from 'sanity/structure';
import { visionTool } from '@sanity/vision';
import { schemaTypes } from './schemaTypes';

export default defineConfig({
  name: 'pweb',
  title: 'P-Web Digitals',
  projectId: process.env.SANITY_STUDIO_PROJECT_ID || 'REPLACE_ME',
  dataset: process.env.SANITY_STUDIO_DATASET || 'production',
  plugins: [
    structureTool({
      structure: (S) =>
        S.list()
          .title('Content')
          .items([
            S.documentTypeListItem('post').title('Blog posts'),
            S.documentTypeListItem('project').title('Portfolio projects'),
            S.documentTypeListItem('template').title('Website templates'),
          ]),
    }),
    visionTool(),
  ],
  schema: { types: schemaTypes },
});
