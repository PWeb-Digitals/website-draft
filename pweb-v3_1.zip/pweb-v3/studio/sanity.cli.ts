import { defineCliConfig } from 'sanity/cli';

export default defineCliConfig({
  api: {
    projectId: process.env.SANITY_STUDIO_PROJECT_ID || 'REPLACE_ME',
    dataset: process.env.SANITY_STUDIO_DATASET || 'production',
  },
  // Your studio will be live at https://pweb.sanity.studio after `npm run deploy` (pick another name if taken)
  studioHost: 'pweb',
});
