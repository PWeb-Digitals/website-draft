import { bundle } from '@remotion/bundler';
import { renderMedia, renderStill, selectComposition } from '@remotion/renderer';
import path from 'node:path';

const browserExecutable = process.env.CHROME || '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome';
const out = path.resolve('../public/videos');
const serveUrl = await bundle({ entryPoint: path.resolve('src/index.ts') });
for (const id of (process.argv[2] ? [process.argv[2]] : ['hero', 'how', 'cta'])) {
  const composition = await selectComposition({ serveUrl, id, browserExecutable });
  await renderMedia({ composition, serveUrl, codec: 'h264', crf: 26, x264Preset: 'veryfast', outputLocation: `${out}/${id}.mp4`, browserExecutable, concurrency: Math.max(1, Math.min(4, (await import("node:os")).cpus().length - 1)), muted: true });
  console.log('rendered', id);
  if (id === 'hero') await renderStill({ composition, serveUrl, output: `${out}/hero-poster.jpg`, frame: 140, imageFormat: 'jpeg', browserExecutable });
}
