import { AbsoluteFill, useCurrentFrame, useVideoConfig } from 'remotion';

const FONT = 'Geist, Inter, ui-sans-serif, system-ui, sans-serif';
const CW = 470, CH = 296, GAP = 56;

type Theme = { bg: string; ink: string; soft: string; accents: string[]; dark?: boolean };
const THEMES: Theme[] = [
  { bg: '#ffffff', ink: '#1b1b1f', soft: '#e9e9ee', accents: ['#7c5cff', '#f472b6', '#fbbf24'] },
  { bg: '#f4f1ff', ink: '#1d1440', soft: '#ddd6fe', accents: ['#8b5cf6', '#ec4899', '#22d3ee'] },
  { bg: '#0f1115', ink: '#f5f5f5', soft: '#262a33', accents: ['#de362a', '#f97316', '#e5e7eb'], dark: true },
  { bg: '#fff7ed', ink: '#24160b', soft: '#fde3c8', accents: ['#f97316', '#de362a', '#84cc16'] },
  { bg: '#f8fafc', ink: '#0f172a', soft: '#e2e8f0', accents: ['#0ea5e9', '#6366f1', '#14b8a6'] },
  { bg: '#ffffff', ink: '#111111', soft: '#ededed', accents: ['#de362a', '#111111', '#a3a3a3'] },
];

const Bar: React.FC<{ w: string | number; h: number; c: string; r?: number; mt?: number }> = ({ w, h, c, r = 4, mt = 0 }) => (
  <div style={{ width: w, height: h, background: c, borderRadius: r, marginTop: mt }} />
);

/** One abstract website screenshot. Layout varies by index so the wall doesn't look repeated. */
const Site: React.FC<{ i: number }> = ({ i }) => {
  const t = THEMES[i % THEMES.length];
  const layout = (i * 7) % 4;
  const nav = (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><div style={{ width: 16, height: 16, borderRadius: 5, background: t.accents[0] }} /><Bar w={54} h={8} c={t.ink} /></div>
      <div style={{ display: 'flex', gap: 10 }}>{[0, 1, 2, 3].map((k) => <Bar key={k} w={28} h={6} c={t.soft} />)}</div>
      <div style={{ width: 62, height: 22, borderRadius: 11, background: t.dark ? '#fff' : t.ink }} />
    </div>
  );
  const blob = (c1: string, c2: string, h: number, w: string | number = '100%') => (
    <div style={{ width: w, height: h, borderRadius: 12, background: `linear-gradient(135deg, ${c1}, ${c2})`, position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', width: '60%', height: '120%', right: '-10%', top: '-30%', borderRadius: '50%', background: 'rgba(255,255,255,.22)' }} />
    </div>
  );
  let body: React.ReactNode;
  if (layout === 0) {
    body = (
      <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr', gap: 18, marginTop: 26 }}>
        <div><Bar w="95%" h={16} c={t.ink} /><Bar w="70%" h={16} c={t.ink} mt={8} /><Bar w="85%" h={7} c={t.soft} mt={16} /><Bar w="60%" h={7} c={t.soft} mt={7} />
          <div style={{ display: 'flex', gap: 8, marginTop: 18 }}><div style={{ width: 76, height: 26, borderRadius: 13, background: t.accents[0] }} /><div style={{ width: 60, height: 26, borderRadius: 13, border: `1px solid ${t.soft}` }} /></div></div>
        {blob(t.accents[0], t.accents[1], 150)}
      </div>
    );
  } else if (layout === 1) {
    body = (
      <div style={{ textAlign: 'center', marginTop: 24, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <Bar w="62%" h={18} c={t.ink} /><Bar w="44%" h={18} c={t.ink} mt={8} /><Bar w="50%" h={7} c={t.soft} mt={14} />
        <div style={{ display: 'flex', gap: 10, marginTop: 18 }}>
          {[0, 1, 2, 3, 4].map((k) => <div key={k} style={{ width: 46, height: 46, borderRadius: 23, background: `linear-gradient(135deg, ${t.accents[k % 3]}, ${t.accents[(k + 1) % 3]})`, border: `3px solid ${t.bg}` }} />)}
        </div>
      </div>
    );
  } else if (layout === 2) {
    body = (
      <div style={{ marginTop: 20 }}>
        <Bar w="58%" h={16} c={t.ink} />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginTop: 16 }}>
          {[0, 1, 2].map((k) => <div key={k}>{blob(t.accents[k], t.accents[(k + 2) % 3], 92)}<Bar w="80%" h={6} c={t.soft} mt={8} /><Bar w="50%" h={6} c={t.soft} mt={5} /></div>)}
        </div>
      </div>
    );
  } else {
    body = (
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.2fr', gap: 18, marginTop: 22 }}>
        {blob(t.accents[2], t.accents[0], 168)}
        <div><Bar w={46} h={16} c={t.accents[0]} r={8} /><Bar w="90%" h={15} c={t.ink} mt={12} /><Bar w="72%" h={15} c={t.ink} mt={7} />
          {[0, 1, 2].map((k) => <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: k ? 9 : 16 }}><div style={{ width: 10, height: 10, borderRadius: 5, background: t.accents[1] }} /><Bar w="70%" h={6} c={t.soft} /></div>)}
        </div>
      </div>
    );
  }
  return (
    <div style={{ width: CW, height: CH, borderRadius: 16, background: t.bg, padding: 20, overflow: 'hidden', boxShadow: '0 40px 70px -30px rgba(0,0,0,.9)', fontFamily: FONT }}>
      {nav}
      {body}
    </div>
  );
};

/** 24-second seamless loop: tilted wall of website screenshots drifting diagonally, dimmed so the card on top reads. */
export const CtaBackdrop: React.FC = () => {
  const f = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const shift = (f / durationInFrames) * 2 * (CH + GAP); // two rows per loop; the pattern repeats every two rows, so the end matches the start
  const cols = 7, rows = 8;
  return (
    <AbsoluteFill style={{ background: '#0a0a0a', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%, -50%) rotate(-26deg) skewX(14deg)' }}>
        <div style={{ display: 'grid', gridTemplateColumns: `repeat(${cols}, ${CW}px)`, gap: GAP, transform: `translateY(${-shift}px)` }}>
          {Array.from({ length: cols * rows }).map((_, i) => {
            const row = Math.floor(i / cols), col = i % cols;
            return <Site key={i} i={((row % 2) * 6 + col * 5) % 12} />;
          })}
        </div>
      </div>
      <AbsoluteFill style={{ background: 'rgba(10,10,10,.5)' }} />
    </AbsoluteFill>
  );
};
