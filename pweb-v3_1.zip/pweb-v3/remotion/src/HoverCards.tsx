import { AbsoluteFill, interpolate, useCurrentFrame, Easing } from 'remotion';

const FONT = 'Geist, Inter, ui-sans-serif, system-ui, sans-serif';

/** 6-second loop: a cursor visits four cards; each lifts and reveals a detail on hover. */
export const HoverCards: React.FC = () => {
  const f = useCurrentFrame();
  const stops = [
    { x: 230, y: 250 }, { x: 570, y: 250 }, { x: 570, y: 600 }, { x: 230, y: 600 }, { x: 230, y: 250 },
  ];
  const seg = Math.min(3, Math.floor(f / 45));
  const t = interpolate(f % 45, [0, 22], [0, 1], { extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic) });
  const a = stops[seg], b = stops[seg + 1];
  const x = a.x + (b.x - a.x) * t, y = a.y + (b.y - a.y) * t;
  const hovered = t >= 0.95 ? (seg + 1) % 4 : seg;
  const cards = [
    { left: 60, top: 80 }, { left: 410, top: 80 }, { left: 410, top: 430 }, { left: 60, top: 430 },
  ];
  return (
    <AbsoluteFill style={{ background: '#f1f1f1', fontFamily: FONT }}>
      {cards.map((c, i) => {
        const on = i === hovered ? 1 : 0;
        return (
          <div key={i} style={{ position: 'absolute', left: c.left, top: c.top, width: 330, height: 310, borderRadius: 18, background: '#fff', boxShadow: on ? '0 30px 50px -20px rgba(0,0,0,.35)' : '0 1px 2px rgba(0,0,0,.08)', transform: `translateY(${on ? -10 : 0}px)`, transition: 'none', padding: 22, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
            <div style={{ height: 150, borderRadius: 12, background: i % 2 ? '#0a0a0a' : 'repeating-linear-gradient(135deg,#ececec 0 10px,#e4e4e4 10px 20px)', position: 'relative', overflow: 'hidden' }}>
              <div style={{ position: 'absolute', left: 16, bottom: 16, width: on ? 120 : 60, height: 10, borderRadius: 5, background: i % 2 ? '#de362a' : '#0a0a0a' }} />
            </div>
            <div>
              <div style={{ fontSize: 22, fontWeight: 600, letterSpacing: -0.5 }}>Card {i + 1}</div>
              <div style={{ marginTop: 6, fontSize: 16, color: '#5e5e5e', opacity: on ? 1 : 0.6 }}>{on ? 'Hover detail appears here' : 'Short description'}</div>
            </div>
          </div>
        );
      })}
      <svg width="30" height="30" viewBox="0 0 24 24" style={{ position: 'absolute', left: x, top: y, filter: 'drop-shadow(0 2px 3px rgba(0,0,0,.3))' }}>
        <path d="M4 2l15 9-6.5 1.5L9.5 19z" fill="#0a0a0a" stroke="#fff" strokeWidth="1.5" strokeLinejoin="round" />
      </svg>
    </AbsoluteFill>
  );
};
