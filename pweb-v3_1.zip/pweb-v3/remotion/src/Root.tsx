import { Composition } from 'remotion';
import { HeroDemo } from './HeroDemo';
import { HoverCards } from './HoverCards';
import { CtaBackdrop } from './CtaBackdrop';

export const Root = () => (
  <>
    <Composition id="hero" component={HeroDemo} durationInFrames={300} fps={30} width={1600} height={900} />
    <Composition id="how" component={HoverCards} durationInFrames={180} fps={30} width={800} height={820} />
    <Composition id="cta" component={CtaBackdrop} durationInFrames={720} fps={30} width={1920} height={1080} />
  </>
);
