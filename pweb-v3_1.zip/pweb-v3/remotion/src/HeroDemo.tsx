import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig, Easing } from 'remotion';

const FONT = 'Geist, Inter, ui-sans-serif, system-ui, sans-serif';
const RED = '#006ef5';

/** 10-second loop: a chat panel on the left "asks" for a section, the preview on the right builds it, then the cursor flips a toggle. */
export const HeroDemo: React.FC = () => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const fadeOut = interpolate(f, [282, 300], [1, 0], { extrapolateLeft: 'clamp' });
  const fadeIn = interpolate(f, [0, 10], [0, 1], { extrapolateRight: 'clamp' });

  const msgs = [
    { at: 12, me: true, text: 'Add online booking with a deposit to my site.' },
    { at: 60, me: false, text: 'Done. Customers pick a time, pay the deposit by Paystack, and you get a WhatsApp alert.' },
    { at: 150, me: true, text: 'Show next week by default.' },
    { at: 196, me: false, text: 'Updated. The calendar now opens on next week.' },
  ];

  const word = (start: number, i: number) => interpolate(f, [start + i * 3, start + i * 3 + 10], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic) });
  const titleWords = ['Book', 'your', 'appointment', 'in', 'a', 'minute.'];
  const cardIn = spring({ frame: f - 96, fps, config: { damping: 16, mass: 0.8 } });
  const toggleRight = interpolate(f, [226, 238], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic) });
  const slot = toggleRight > 0.5 ? 'Mon · 14:00' : 'Sat · 10:00';

  // cursor path
  const cx = interpolate(f, [120, 200, 224, 260], [1240, 1060, 1010, 1180], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic) });
  const cy = interpolate(f, [120, 200, 224, 260], [760, 300, 262, 520], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic) });
  const click = interpolate(f, [224, 228, 234], [1, 0.8, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });

  return (
    <AbsoluteFill style={{ background: '#e9e9e9', fontFamily: FONT, opacity: Math.min(fadeIn, fadeOut) }}>
      {/* left chat panel */}
      <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 440, background: '#0f0f0f', padding: 28, display: 'flex', flexDirection: 'column', gap: 16 }}>
        {msgs.map((m, i) => {
          const o = interpolate(f, [m.at, m.at + 12], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
          const chars = Math.floor(interpolate(f, [m.at, m.at + 36], [0, m.text.length], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }));
          return (
            <div key={i} style={{ opacity: o, transform: `translateY(${(1 - o) * 10}px)`, alignSelf: m.me ? 'flex-end' : 'flex-start', maxWidth: '86%', background: m.me ? '#262626' : 'transparent', color: m.me ? '#fff' : '#d0d0d0', borderRadius: 14, padding: m.me ? '12px 16px' : 0, fontSize: 20, lineHeight: 1.45 }}>
              {m.me ? m.text : m.text.slice(0, chars)}
            </div>
          );
        })}
        <div style={{ marginTop: 'auto', height: 56, borderRadius: 14, background: '#1c1c1c', border: '1px solid #2a2a2a', display: 'flex', alignItems: 'center', padding: '0 18px', color: '#6b6b6b', fontSize: 18 }}>
          Type / for commands
        </div>
      </div>

      {/* right preview */}
      <div style={{ position: 'absolute', left: 456, right: 16, top: 16, bottom: 16, background: '#f6f5f2', borderRadius: 16, overflow: 'hidden' }}>
        <div style={{ height: 64, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 28px', borderBottom: '1px solid #e7e5df' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontWeight: 600, fontSize: 20 }}><span style={{ width: 22, height: 22, borderRadius: 6, background: '#0a0a0a' }} />Your business</div>
          <div style={{ display: 'flex', gap: 28, color: '#6b6b6b', fontSize: 16 }}>{['Services', 'Gallery', 'Prices', 'Contact'].map((x) => <span key={x}>{x}</span>)}</div>
          <span style={{ background: '#0a0a0a', color: '#fff', borderRadius: 20, padding: '8px 16px', fontSize: 15 }}>Book now</span>
        </div>

        <div style={{ textAlign: 'center', marginTop: 46 }}>
          <div style={{ fontSize: 54, fontWeight: 600, letterSpacing: -2, lineHeight: 1.05, color: '#0a0a0a', maxWidth: 640, margin: '0 auto' }}>
            {titleWords.map((w, i) => (
              <span key={i} style={{ display: 'inline-block', marginRight: 14, opacity: word(70, i), transform: `translateY(${(1 - word(70, i)) * 18}px)` }}>{w}</span>
            ))}
          </div>
          <p style={{ marginTop: 18, fontSize: 19, color: '#6b6b6b', opacity: word(92, 0) }}>Pick a time and pay a small deposit to confirm.</p>
        </div>

        {/* toggle */}
        <div style={{ position: 'relative', width: 420, height: 54, margin: '30px auto 0', background: '#ebe9e3', borderRadius: 14, padding: 5, display: 'grid', gridTemplateColumns: '1fr 1fr', opacity: cardIn, fontSize: 17 }}>
          <div style={{ position: 'absolute', top: 5, bottom: 5, left: 5, width: 'calc(50% - 5px)', background: '#fff', borderRadius: 10, boxShadow: '0 1px 2px rgba(0,0,0,.08)', transform: `translateX(${toggleRight * 100}%)` }} />
          <span style={{ position: 'relative', display: 'grid', placeItems: 'center', fontWeight: 600 }}>This week</span>
          <span style={{ position: 'relative', display: 'grid', placeItems: 'center', fontWeight: 600 }}>Next week</span>
        </div>

        {/* card */}
        <div style={{ width: 640, height: 300, margin: '26px auto 0', background: '#0e1117', borderRadius: 16, display: 'grid', gridTemplateColumns: '1fr 1fr', padding: 18, gap: 18, transform: `translateY(${(1 - cardIn) * 40}px) scale(${0.96 + 0.04 * cardIn})`, opacity: cardIn, boxShadow: '0 30px 60px -20px rgba(0,0,0,.4)' }}>
          <div style={{ background: '#161b22', borderRadius: 12, padding: 22, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', color: '#fff' }}>
            <div style={{ fontSize: 26, fontWeight: 600, lineHeight: 1.15 }}>{slot}</div>
            <div><div style={{ color: '#9aa4b2', fontSize: 15 }}>Deposit by Paystack</div><div style={{ fontSize: 44, fontWeight: 700 }}>Confirmed<span style={{ color: RED }}>.</span></div></div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14, color: '#e6e6e6', fontSize: 16, paddingTop: 6 }}>
            {['WhatsApp alert to you', 'Added to your calendar', 'Reminder the day before', 'Receipt sent automatically'].map((x, i) => (
              <div key={x} style={{ display: 'flex', gap: 10, alignItems: 'center', opacity: interpolate(f, [110 + i * 6, 122 + i * 6], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }) }}>
                <span style={{ width: 18, height: 18, borderRadius: 9, background: '#006ef5' }} />{x}
              </div>
            ))}
            <div style={{ marginTop: 'auto', background: '#fff', color: '#0a0a0a', borderRadius: 24, textAlign: 'center', padding: '12px 0', fontWeight: 600 }}>Book this slot →</div>
          </div>
        </div>
      </div>

      {/* cursor */}
      <svg width="30" height="30" viewBox="0 0 24 24" style={{ position: 'absolute', left: cx, top: cy, transform: `scale(${click})`, opacity: interpolate(f, [118, 128], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }), filter: 'drop-shadow(0 2px 3px rgba(0,0,0,.3))' }}>
        <path d="M4 2l15 9-6.5 1.5L9.5 19z" fill="#0a0a0a" stroke="#fff" strokeWidth="1.5" strokeLinejoin="round" />
      </svg>
    </AbsoluteFill>
  );
};
