# Blog on Sanity: setup guide (do this once, about 20 minutes)

How it works once set up:
1. You write a post in **Sanity Studio** (your dashboard) and click **Publish**.
2. Sanity calls the website's `/api/revalidate-blog` link.
3. Only the blog pages refresh. **No Netlify deploy, no deploy credits.** The post is live within seconds.

Your posts live in Sanity's cloud, not in Notion and not in the code. Backups: see step 7.

---

## 1. Create the Sanity project
1. Go to **sanity.io** and sign up (Google login with info@pwebdigitals.com is fine).
2. Create a new project called **P-Web Digitals**. Choose dataset name **production** and set it to **Public** (blog content is public anyway, and it means the website needs no secret key to read it).
3. Copy the **Project ID** (8 characters, shown at sanity.io/manage).

## 2. Run the Studio on your laptop
Open a terminal in the website folder, then:
```
cd studio
copy .env.example .env
```
Open `studio/.env` and paste your Project ID after `SANITY_STUDIO_PROJECT_ID=`. Then:
```
npm install
npm run dev
```
Open http://localhost:3333 and log in. You'll see **Blog posts** and **Portfolio projects**.

## 3. Put the Studio online (so you can write from your phone too)
```
npm run deploy
```
It gives you a link like **https://pweb.sanity.studio** (if "pweb" is taken, change `studioHost` in `studio/sanity.cli.ts`). Bookmark it.

## 4. Allow the website to read Sanity
At sanity.io/manage → your project → **API** → **CORS origins**, add:
- `http://localhost:3007`
- `https://pwebdigitals.com`

## 5. Connect the website
Add these to the website's `.env.local` (your laptop) **and** to Netlify → Site configuration → Environment variables:
```
NEXT_PUBLIC_SANITY_PROJECT_ID=your-project-id
NEXT_PUBLIC_SANITY_DATASET=production
REVALIDATION_SECRET=make-up-a-long-random-string
```
Netlify needs **one** deploy after adding these (that's the last deploy the blog will ever need).

## 6. Instant publishing (the webhook)
sanity.io/manage → your project → **API** → **Webhooks** → **Create webhook**:
- Name: `Refresh website blog`
- URL: `https://pwebdigitals.com/api/revalidate-blog?secret=` + the same REVALIDATION_SECRET
- Dataset: `production`
- Trigger on: **Create, Update, Delete**
- Filter: `_type == "post"`
- Projection: `{"slug": slug.current}`
- HTTP method: **POST**

Test it: publish a post, wait a few seconds, refresh pwebdigitals.com/blog.

## 7. Backups (so nothing is ever lost)
In the `studio` folder:
```
npm run backup
```
It saves everything (posts + images) to `studio/backups/production.tar.gz`. Do it weekly, or ask Claude to set up a scheduled task for it. Sanity also keeps a revision history of every document, so you can restore an older version of any post from the Studio.

## 8. Writing a post (every time)
1. Studio → **Blog posts** → **+**.
2. Fill in **Title**, click **Generate** next to Slug, add **Excerpt**, **Category**, **Cover image** (with alt text), then write the **Body**. Use Heading 2 for main sections.
3. Optional **SEO** tab: a shorter Google title and description.
4. Click **Publish**. Done.

Never change a slug after publishing: it changes the URL and you lose Google ranking.

## 9. Letting n8n send drafts (your Telegram approval flow)
1. sanity.io/manage → **API** → **Tokens** → add a token with **Editor** rights. Keep it only inside n8n credentials, never in chat or code.
2. In n8n, when you approve a draft in Telegram, send an HTTP request:
   - `POST https://YOUR_PROJECT_ID.api.sanity.io/v2025-01-01/data/mutate/production`
   - Header `Authorization: Bearer YOUR_TOKEN`
   - Body:
```json
{
  "mutations": [{
    "create": {
      "_id": "drafts.post-{{ $now.toMillis() }}",
      "_type": "post",
      "title": "{{ title }}",
      "slug": { "_type": "slug", "current": "{{ slug }}" },
      "excerpt": "{{ excerpt }}",
      "publishedAt": "{{ $now.toISO() }}",
      "body": [{ "_type": "block", "_key": "p1", "style": "normal", "markDefs": [], "children": [{ "_type": "span", "_key": "s1", "text": "{{ paragraph text }}", "marks": [] }] }]
    }
  }]
}
```
   The `drafts.` prefix means it lands in the Studio as a **draft**. You open it, add the cover image, check it, and click **Publish**. To publish straight away without checking, remove `drafts.` from the `_id`.
   Each paragraph becomes one block in `body` (give each its own `_key`). Ask Claude to build this n8n node when you're ready.

## What's in the code
- `studio/`: the Sanity Studio (dashboard) and the post/project fields
- `src/lib/sanity.ts`, `src/lib/blog.ts`: how the website reads posts
- `src/components/blog/PostBody.tsx`: how the post body is displayed
- `src/app/api/revalidate-blog/route.ts`: the webhook that refreshes pages
- If Sanity isn't connected, the blog simply shows "no articles". It never shows fake posts.
