import nodemailer from 'nodemailer';

export interface LeadEmailPayload {
  name: string;
  email: string;
  phone?: string;
  organization?: string;
  pathway?: string;
  bottleneck?: string;
  budget?: string;
  submittedAt?: string;
  source?: string;
}

const GMAIL_DESTINATION = 'pwebsdigitals@gmail.com';
const PROFESSIONAL_EMAIL = 'info@pwebdigitals.com';

export async function sendLeadNotificationEmail(lead: LeadEmailPayload): Promise<{ success: boolean; messageId?: string; simulated?: boolean; error?: string }> {
  const gmailUser = (process.env.GMAIL_USER || GMAIL_DESTINATION).trim();
  const rawPass = process.env.GMAIL_APP_PASSWORD || process.env.SMTP_PASSWORD;
  const gmailPass = rawPass ? rawPass.replace(/\s+/g, '') : undefined;

  const submittedDate = lead.submittedAt
    ? new Date(lead.submittedAt).toLocaleString('en-US', {
        timeZone: 'Africa/Lagos',
        dateStyle: 'full',
        timeStyle: 'medium',
      })
    : new Date().toLocaleString();

  const pathwayLabel = {
    grow: 'Growth & High-Converting Funnel',
    build: 'Digital Architecture & Web Experience',
    partner: 'Strategic Studio Retainer & Fractional Systems',
    media: 'Creative Content, Video & Launch Media',
    general: 'General Project Discovery',
  }[lead.pathway?.toLowerCase() || 'general'] || lead.pathway;

  const htmlContent = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #000f22; color: #FFFFFF; margin: 0; padding: 24px; }
          .container { max-width: 600px; margin: 0 auto; background: #0a1424; border: 1px solid rgba(128, 170, 211, 0.25); border-radius: 20px; overflow: hidden; }
          .header { padding: 32px 32px 24px; background: linear-gradient(135deg, rgba(192, 230, 253, 0.15) 0%, rgba(27, 53, 84, 0.4) 100%); border-bottom: 1px solid rgba(128, 170, 211, 0.2); }
          .eyebrow { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 11px; text-transform: uppercase; letter-spacing: 2px; color: #c0e6fd; margin-bottom: 8px; font-weight: 700; }
          .title { font-size: 24px; font-weight: 800; margin: 0; color: #FFFFFF; letter-spacing: -0.02em; }
          .body { padding: 32px; }
          .field { margin-bottom: 24px; }
          .label { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; color: #80aad3; margin-bottom: 6px; }
          .value { font-size: 16px; font-weight: 600; color: #FFFFFF; line-height: 1.5; }
          .value-block { background: rgba(0, 15, 34, 0.6); border: 1px solid rgba(128, 170, 211, 0.2); border-radius: 12px; padding: 16px; font-size: 14px; font-weight: normal; color: #c0e6fd; white-space: pre-wrap; line-height: 1.6; }
          .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
          .badge { display: inline-block; padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: 600; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: rgba(128, 170, 211, 0.15); color: #c0e6fd; border: 1px solid rgba(192, 230, 253, 0.3); }
          .cta-btn { display: inline-block; margin-top: 16px; padding: 14px 28px; background: linear-gradient(135deg, #c0e6fd 0%, #80aad3 50%, #1b3554 100%); color: #000f22; text-decoration: none; font-weight: 800; font-size: 14px; border-radius: 12px; }
          .footer { padding: 20px 32px; border-top: 1px solid rgba(128, 170, 211, 0.15); font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 11px; color: #80aad3; text-align: center; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="eyebrow">P-WEB DIGITALS · NEW INTAKE BRIEF</div>
            <h1 class="title">New Client Discovery Request</h1>
          </div>
          <div class="body">
            <div class="grid">
              <div class="field">
                <div class="label">Client Name</div>
                <div class="value">${lead.name}</div>
              </div>
              <div class="field">
                <div class="label">Organization / Brand</div>
                <div class="value">${lead.organization || 'Not specified'}</div>
              </div>
            </div>

            <div class="grid">
              <div class="field">
                <div class="label">Direct Email</div>
                <div class="value"><a href="mailto:${lead.email}" style="color: #c0e6fd; text-decoration: none;">${lead.email}</a></div>
              </div>
              <div class="field">
                <div class="label">Phone / WhatsApp</div>
                <div class="value">${lead.phone ? `<a href="https://wa.me/${lead.phone.replace(/[^0-9]/g, '')}" style="color: #25D366; text-decoration: none;">${lead.phone}</a>` : 'Not provided'}</div>
              </div>
            </div>

            <div class="grid">
              <div class="field">
                <div class="label">Target Budget</div>
                <div class="value"><span class="badge">${lead.budget || 'Flexible'}</span></div>
              </div>
            </div>

            <div class="field">
              <div class="label">Selected Project Pathway</div>
              <div class="value" style="color: #c0e6fd; font-weight: 700;">${pathwayLabel}</div>
            </div>

            <div class="field">
              <div class="label">Current Bottleneck / Platform Scope</div>
              <div class="value-block">${lead.bottleneck || 'No specific notes provided.'}</div>
            </div>

            <div style="text-align: center; margin-top: 32px;">
              <a href="mailto:${lead.email}?subject=Re:%20P-Web%20Digitals%20Project%20Discovery%20—%20${encodeURIComponent(lead.name)}" class="cta-btn">
                Reply to ${lead.name} Directly
              </a>
            </div>
          </div>
          <div class="footer">
            Submitted via P-Web Digitals Website (/contact) · ${submittedDate} (WAT)
          </div>
        </div>
      </body>
    </html>
  `;

  const textContent = `
NEW PROJECT INTAKE BRIEF — P-WEB DIGITALS
==========================================
Client Name:    ${lead.name}
Organization:   ${lead.organization || 'Not specified'}
Email:          ${lead.email}
Target Budget:  ${lead.budget || 'Flexible'}
Pathway:        ${pathwayLabel}
Submitted At:   ${submittedDate}

PROJECT BOTTLENECK / VISION:
------------------------------------------
${lead.bottleneck || 'No specific notes provided.'}
==========================================
Reply directly to: ${lead.email}
  `;

  // If Gmail App Password is not provided yet, log simulation mode
  if (!gmailPass) {
    console.log('\n[Email Service - Simulation Mode]');
    console.log(`Destinations: ${PROFESSIONAL_EMAIL}, ${GMAIL_DESTINATION}`);
    console.log(`From Client: ${lead.name} <${lead.email}>`);
    console.log(`Subject: New Project Brief: ${lead.name} (${lead.organization || 'Individual'})`);
    console.log(`To enable live Gmail delivery, add GMAIL_APP_PASSWORD to your .env.local file.`);
    console.log('--------------------------------------------------\n');
    return {
      success: true,
      simulated: true,
      messageId: `simulated-${Date.now()}`,
    };
  }

  try {
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: gmailUser,
        pass: gmailPass,
      },
    });

    const info = await transporter.sendMail({
      from: `"P-Web Digitals Intake" <${gmailUser}>`,
      to: [PROFESSIONAL_EMAIL, GMAIL_DESTINATION],
      replyTo: `${lead.name} <${lead.email}>`,
      subject: `⚡ New Project Intake: ${lead.name} (${lead.organization || 'Individual'}) — ${lead.budget || 'Flexible'}`,
      text: textContent,
      html: htmlContent,
    });

    console.log(`[Email Service] Email successfully delivered to ${PROFESSIONAL_EMAIL} & ${GMAIL_DESTINATION}. Message ID: ${info.messageId}`);
    return {
      success: true,
      messageId: info.messageId,
    };
  } catch (error: any) {
    console.error('[Email Service] Error sending email via Gmail:', error);
    return {
      success: false,
      error: error.message,
    };
  }
}
