import { createClient, type SanityClient } from '@sanity/client';
import { createImageUrlBuilder } from '@sanity/image-url';

/**
 * Sanity connection. Set these in .env.local (and in Netlify > Site settings > Environment variables):
 *   NEXT_PUBLIC_SANITY_PROJECT_ID=xxxxxxxx
 *   NEXT_PUBLIC_SANITY_DATASET=production
 * The dataset is read-only from the website, so no token is needed here.
 */
export const sanityProjectId = process.env.NEXT_PUBLIC_SANITY_PROJECT_ID || '';
export const sanityDataset = process.env.NEXT_PUBLIC_SANITY_DATASET || 'production';
export const sanityConfigured = Boolean(sanityProjectId);

let client: SanityClient | null = null;
export function sanity(): SanityClient | null {
  if (!sanityConfigured) return null;
  if (!client) {
    client = createClient({
      projectId: sanityProjectId,
      dataset: sanityDataset,
      apiVersion: '2025-01-01',
      useCdn: false, // always fresh; pages are cached by Next and refreshed by the publish webhook
      perspective: 'published',
    });
  }
  return client;
}

const builder = sanityConfigured ? createImageUrlBuilder({ projectId: sanityProjectId, dataset: sanityDataset }) : null;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function imageUrl(source: any, width = 1200): string {
  if (!builder || !source?.asset) return '';
  return builder.image(source).width(width).auto('format').fit('max').url();
}
