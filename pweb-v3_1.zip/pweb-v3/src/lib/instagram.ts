/**
 * Latest Instagram posts through the official Instagram API (Instagram Login).
 * Needs INSTAGRAM_ACCESS_TOKEN: a long-lived token for the @pweb_digitals Business/Creator account.
 * Long-lived tokens expire after about 60 days unless refreshed. Refresh it with your n8n job, then update
 * the value in Netlify. Without a token the Instagram section simply doesn't show.
 * Endpoint details: check developers.facebook.com/docs/instagram-platform before changing anything here.
 */
export type IgPost = { id: string; caption: string; image: string; permalink: string; video: boolean };

export async function getInstagramPosts(limit = 12): Promise<IgPost[]> {
  const token = process.env.INSTAGRAM_ACCESS_TOKEN;
  if (!token) return [];
  try {
    const fields = 'id,caption,media_type,media_url,thumbnail_url,permalink';
    const res = await fetch(`https://graph.instagram.com/me/media?fields=${fields}&limit=${limit}&access_token=${encodeURIComponent(token)}`, {
      next: { revalidate: 3600 },
    });
    if (!res.ok) {
      console.error('[instagram] API error', res.status);
      return [];
    }
    const json = await res.json();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return (json.data || []).map((m: any) => ({
      id: m.id,
      caption: (m.caption || '').split('\n')[0].slice(0, 140),
      image: m.media_type === 'VIDEO' ? m.thumbnail_url : m.media_url,
      permalink: m.permalink,
      video: m.media_type === 'VIDEO',
    })).filter((p: IgPost) => p.image);
  } catch (err) {
    console.error('[instagram] fetch failed', err);
    return [];
  }
}
