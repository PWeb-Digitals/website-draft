export type ServiceFeature = { icon: string; title: string; desc: string };
export type ServiceFaq = { q: string; a: string };
export type ServiceData = {
  slug: string;
  eyebrow: string;
  title: string;
  sub: string;
  platforms: string[];
  features: ServiceFeature[];
  includes: string[];
  faqs: ServiceFaq[];
  related: string[];
};

/** Icon names map to lucide icons in ServicePage. Platform keys map to platforms.tsx. */
export const SERVICE_DATA: Record<string, ServiceData> = {
  'web-design': {
    slug: 'web-design',
    eyebrow: 'WEB DESIGN',
    title: 'Websites that turn visitors into customers.',
    sub: 'Custom websites designed on a phone screen first, quick to load and clear to read, with booking, payments and follow-up built in.',
    platforms: ['wordpress', 'webflow', 'framer', 'shopify', 'figma', 'gsc', 'ga', 'cal', 'paystack', 'stripe'],
    features: [
      { icon: 'Smartphone', title: 'Phone first', desc: 'Most of your visitors are on a phone, so that is where every layout starts.' },
      { icon: 'Gauge', title: 'Quick to load', desc: 'Compressed images, clean code and good hosting, so people don’t leave while it loads.' },
      { icon: 'MousePointerClick', title: 'One clear next step', desc: 'Every page leads somewhere: book, buy, call or send a message.' },
      { icon: 'Search', title: 'Ready for Google', desc: 'Titles, descriptions, sitemap and Search Console set up from day one.' },
      { icon: 'CalendarCheck', title: 'Booking and payments', desc: 'Take appointments and deposits straight from the site.' },
      { icon: 'PencilLine', title: 'Easy to update', desc: 'Change text, photos and prices yourself, without calling a developer.' },
    ],
    includes: ['Design and build of every page', 'Copy written with you', 'Mobile, tablet and desktop layouts', 'Contact forms connected to email and WhatsApp', 'Google Search Console and Analytics', 'Short video guides at handover'],
    faqs: [
      { q: 'How long does a website take?', a: 'Most sites take 2 to 4 weeks, depending on the number of pages and how quickly we get your content.' },
      { q: 'Can I update it myself?', a: 'Yes. You get access to edit text, images and prices, plus short videos showing how.' },
      { q: 'Do I own the website?', a: 'Yes. The domain, files and logins are in your name.' },
    ],
    related: ['crm-automation', 'seo', 'ai-automation'],
  },
  'ai-automation': {
    slug: 'ai-automation',
    eyebrow: 'AI AUTOMATION & VOICE AGENTS',
    title: 'Answer every customer in seconds, day or night.',
    sub: 'Chat assistants, WhatsApp replies and phone agents trained on your business. They answer questions, book appointments and hand over to you when needed.',
    platforms: ['openai', 'claude', 'elevenlabs', 'vapi', 'whatsapp', 'telegram', 'n8n', 'make', 'zapier', 'gmail'],
    features: [
      { icon: 'MessageSquare', title: 'Website chat', desc: 'Answers questions about your services, prices and hours on your site.' },
      { icon: 'MessageCircle', title: 'WhatsApp replies', desc: 'Replies to new messages instantly and sends booking or payment links.' },
      { icon: 'PhoneCall', title: 'Phone agent', desc: 'Picks up calls you miss, answers questions and books appointments.' },
      { icon: 'UserRoundCheck', title: 'Hands over to you', desc: 'When it can’t help, it passes the full conversation to you.' },
      { icon: 'Repeat', title: 'Admin on autopilot', desc: 'Invoices, reminders, reports and data entry run on their own.' },
      { icon: 'FileText', title: 'Every conversation saved', desc: 'Transcripts and lead details land in your CRM or inbox.' },
    ],
    includes: ['Assistant trained on your business', 'Website chat and/or WhatsApp setup', 'Phone number and voice agent (optional)', 'Connection to your calendar and CRM', 'Testing with real questions before launch', 'Monthly review of conversations'],
    faqs: [
      { q: 'Will it sound like a robot?', a: 'We write its replies in your tone and test them with real questions before it goes live. You approve the script.' },
      { q: 'What if it gets something wrong?', a: 'It only answers from information you give it, and it hands over to you when it is unsure.' },
      { q: 'Can it work with Nigerian numbers?', a: 'Yes for WhatsApp and website chat. For phone agents we check what works for your country on the call.' },
    ],
    related: ['crm-automation', 'web-design', 'mvp-development'],
  },
  'crm-automation': {
    slug: 'crm-automation',
    eyebrow: 'CRM & FOLLOW-UP',
    title: 'Every lead tracked, booked, paid and followed up.',
    sub: 'One pipeline for every enquiry, with booking, payments, reminders and review requests running on their own.',
    platforms: ['ghl', 'hubspot', 'airtable', 'cal', 'gcal', 'paystack', 'stripe', 'paypal', 'brevo', 'mailchimp', 'whatsapp', 'n8n'],
    features: [
      { icon: 'KanbanSquare', title: 'One pipeline', desc: 'See who is new, who replied, who booked and who paid, at a glance.' },
      { icon: 'Zap', title: 'Instant replies', desc: 'New enquiries get a text or email within seconds.' },
      { icon: 'CalendarCheck', title: 'Booking that syncs', desc: 'Appointments go straight into the calendar you already use.' },
      { icon: 'CreditCard', title: 'Payments and receipts', desc: 'Deposits and invoices by Paystack, Stripe or PayPal, with receipts sent automatically.' },
      { icon: 'BellRing', title: 'Reminders', desc: 'Fewer no-shows, with reminders by email, SMS or WhatsApp.' },
      { icon: 'Star', title: 'Review requests', desc: 'Happy customers are asked for a Google review at the right time.' },
    ],
    includes: ['Pipeline set up for how you sell', 'Forms and website connected', 'Booking calendar', 'Payment links and receipts', 'Email and SMS follow-up sequences', 'Team training'],
    faqs: [
      { q: 'Which CRM do you use?', a: 'We pick the one that fits your budget and team. We often use one we set up for you, or connect HubSpot or Airtable if you already have them.' },
      { q: 'Can my team use it?', a: 'Yes. We set up logins for your team and show them how it works.' },
      { q: 'Does it work with my existing website?', a: 'Usually yes. We connect your current forms and booking to the new pipeline.' },
    ],
    related: ['ai-automation', 'web-design', 'lead-generation'],
  },
  'lead-generation': {
    slug: 'lead-generation',
    eyebrow: 'FUNNELS & LEAD GENERATION',
    title: 'Pages and funnels that turn clicks into enquiries.',
    sub: 'Landing pages, lead forms and offers built to convert, connected to instant follow-up so no enquiry goes cold.',
    platforms: ['wordpress', 'webflow', 'framer', 'ghl', 'brevo', 'mailchimp', 'ga', 'whatsapp'],
    features: [
      { icon: 'LayoutTemplate', title: 'Landing pages', desc: 'One page, one offer, one action. Built for the ads or posts sending traffic to it.' },
      { icon: 'ClipboardList', title: 'Lead forms that qualify', desc: 'Ask the right questions up front, so you only spend time on serious buyers.' },
      { icon: 'Zap', title: 'Instant follow-up', desc: 'Every new lead gets a text or email within seconds, plus a reminder sequence.' },
      { icon: 'LineChart', title: 'Tracking that makes sense', desc: 'See which page, post or ad each lead came from.' },
    ],
    includes: ['Landing page design and build', 'Lead form and thank-you page', 'Email and SMS follow-up sequence', 'Analytics and conversion tracking', 'Connection to your CRM'],
    faqs: [{ q: 'Do you run the ads too?', a: 'We build the pages and follow-up. If you need ads, we can recommend a partner or set up a simple starter campaign.' }],
    related: ['web-design', 'crm-automation', 'seo'],
  },
  'ai-video': {
    slug: 'ai-video',
    eyebrow: 'AI VIDEO & EDITING',
    title: 'Short-form video that makes people stop scrolling.',
    sub: 'AI-assisted video and editing for your brand: ads, explainers and content for Instagram, TikTok and YouTube.',
    platforms: ['instagram', 'figma', 'elevenlabs'],
    features: [
      { icon: 'Clapperboard', title: 'Short-form edits', desc: 'Reels, TikToks and Shorts cut from your footage, with captions and music.' },
      { icon: 'Sparkles', title: 'AI video', desc: 'Product and brand videos made with AI tools when you don\u2019t have footage.' },
      { icon: 'Mic', title: 'Voice-overs', desc: 'Natural AI voice-overs in the tone you choose.' },
      { icon: 'CalendarDays', title: 'Monthly packs', desc: 'A steady batch of videos each month, ready to post.' },
    ],
    includes: ['Script or outline', 'Editing with captions', 'Music and sound', 'Vertical and square versions', 'Two rounds of changes'],
    faqs: [{ q: 'Do I need to film anything?', a: 'Not always. We can work from your existing photos and clips, or make the video fully with AI tools.' }],
    related: ['web-design', 'lead-generation', 'ai-automation'],
  },
  seo: {
    slug: 'seo',
    eyebrow: 'SEO',
    title: 'Show up when your customers search.',
    sub: 'Technical fixes, local search and content that helps the right people find you on Google.',
    platforms: ['google', 'gsc', 'ga', 'wordpress', 'webflow', 'sanity'],
    features: [
      { icon: 'Wrench', title: 'Technical fixes', desc: 'Speed, indexing, broken links and structured data.' },
      { icon: 'MapPin', title: 'Local search', desc: 'Google Business Profile set up and kept up to date.' },
      { icon: 'FileText', title: 'Content that ranks', desc: 'Pages and articles written around what your customers search for.' },
      { icon: 'LineChart', title: 'Clear reporting', desc: 'A simple monthly update on what moved and what’s next.' },
    ],
    includes: ['Site audit', 'Keyword plan', 'On-page fixes', 'Google Business Profile', 'Monthly report'],
    faqs: [
      { q: 'How long before I see results?', a: 'SEO is slow. Technical fixes show quickly; rankings usually take a few months.' },
    ],
    related: ['web-design', 'lead-generation', 'crm-automation'],
  },
  'mvp-development': {
    slug: 'mvp-development',
    eyebrow: 'MVPS & WEB APPS',
    title: 'Turn your idea into a working product.',
    sub: 'A first version you can click through, test with real users and show to investors.',
    platforms: ['figma', 'stripe', 'paystack', 'openai', 'claude', 'airtable'],
    features: [
      { icon: 'Lightbulb', title: 'Shape the idea', desc: 'We cut the idea down to the few features that prove it works.' },
      { icon: 'LayoutDashboard', title: 'Design', desc: 'Clickable screens you can test before anything is built.' },
      { icon: 'Code2', title: 'Build', desc: 'A working web app with logins, payments and an admin area.' },
      { icon: 'Rocket', title: 'Launch', desc: 'Live on your domain, ready for your first users.' },
    ],
    includes: ['Scope workshop', 'Clickable prototype', 'Working web app', 'Launch support'],
    faqs: [
      { q: 'Do I own the code?', a: 'Yes. Everything is handed over to you.' },
    ],
    related: ['web-design', 'ai-automation', 'crm-automation'],
  },
};
