/** Contact details and links used across the site. Change them here once. */
export const SITE = {
  name: 'P-Web Digitals',
  url: 'https://pwebdigitals.com',
  email: 'info@pwebdigitals.com',
  whatsapp: 'https://wa.me/2348075709405',
  whatsappLabel: '+234 807 570 9405',
  calLink: 'pweb-digitals/consultation',
  founder: 'Peace Azubuike',
  location: 'Akure, Nigeria',
};

export const SOCIALS = [
  { label: 'Instagram', href: 'https://www.instagram.com/pweb_digitals', key: 'instagram' },
  { label: 'X', href: 'https://x.com/pweb_digitals', key: 'x' },
  { label: 'LinkedIn', href: 'https://www.linkedin.com/in/azubuike-peace-0b56b8435/', key: 'linkedin' },
  { label: 'Telegram', href: 'https://t.me/pwebdigitals', key: 'telegram' },
  { label: 'WhatsApp', href: 'https://wa.me/2348075709405', key: 'whatsapp' },
] as const;

/** Shared metadata helper so every page gets a title, description, canonical and Open Graph. */
export function pageMeta(path: string, title: string, description: string, image = '/images/og.jpg') {
  const url = `${SITE.url}${path === '/' ? '' : path}`;
  return {
    title,
    description,
    alternates: { canonical: url },
    openGraph: { title, description, url, type: 'website' as const, siteName: SITE.name, images: [{ url: image, width: 1200, height: 630 }] },
    twitter: { card: 'summary_large_image' as const, title, description, images: [image] },
  };
}
