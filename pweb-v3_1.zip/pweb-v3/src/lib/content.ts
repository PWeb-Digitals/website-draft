import { sanity, imageUrl } from './sanity';

/* ------------------------------------------------------------------ */
/* Portfolio                                                            */
/* ------------------------------------------------------------------ */

export type Project = { name: string; slug: string; tag: string; desc: string; img: string; href?: string };

/** Live client sites. Used until projects are added in Sanity (then Sanity wins). */
export const WORK_FALLBACK: Project[] = [
  { name: 'Sidney Sanni', slug: 'sidney-sanni', tag: 'Website · Booking', desc: 'Personal brand site for a publishing consultant with 20+ years in the industry. Consultation booking, his book, podcast and speaking in one place.', img: '/images/work/sidney-sanni.webp', href: 'https://sidneysanni.com' },
  { name: 'Jennifer Vassel', slug: 'jennifer-vassel', tag: 'Website · Store', desc: 'Editorial site and online store for a bestselling author and speaker.', img: '/images/work/jennifer-vassel.webp', href: 'https://www.jennifervassel.com' },
  { name: 'BWM', slug: 'bwm', tag: 'Platform · Dashboard', desc: 'Website for an affiliate platform, with a member dashboard.', img: '/images/work/bwm.webp', href: 'https://bwm-inc.com' },
  { name: 'Industrial Jewellery', slug: 'industrial-jewellery', tag: 'E-commerce', desc: 'Online store for a London jewellery brand.', img: '/images/work/industrial-jewellery.webp', href: 'https://www.industrial-jewellery.com' },
];

export async function getProjects(): Promise<Project[]> {
  const c = sanity();
  if (!c) return WORK_FALLBACK;
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const docs: any[] = await c.fetch(`*[_type == "project" && defined(slug.current)] | order(coalesce(order, 999) asc, _createdAt desc) { title, "slug": slug.current, tags, summary, liveUrl, cover }`);
    if (!docs.length) return WORK_FALLBACK;
    return docs.map((d) => ({
      name: d.title,
      slug: d.slug,
      tag: (d.tags || []).join(' · '),
      desc: d.summary || '',
      img: imageUrl(d.cover, 1600) || '/images/og.jpg',
      href: d.liveUrl || undefined,
    }));
  } catch (err) {
    console.error('[work] Sanity query failed:', err);
    return WORK_FALLBACK;
  }
}

/* ------------------------------------------------------------------ */
/* Templates                                                           */
/* ------------------------------------------------------------------ */

export type Template = {
  title: string;
  slug: string;
  summary: string;
  features: string[];
  demoUrl?: string;
  cover?: string;
  priceLabel?: string;
  paymentUrl?: string;
};

/** Shown until templates are added in Sanity. Demo and payment links come from Sanity or the env vars below. */
export const TEMPLATES_FALLBACK: Template[] = [
  {
    title: 'Restaurant',
    slug: 'restaurant',
    summary: 'Menu, online ordering, table booking, order tracking and Paystack payments, ready for your restaurant or food business.',
    features: ['Menu with photos and prices', 'Online ordering', 'Table booking', 'Order tracking', 'Paystack payments', 'WhatsApp order alerts'],
    demoUrl: process.env.NEXT_PUBLIC_RESTAURANT_DEMO_URL || undefined,
    paymentUrl: process.env.NEXT_PUBLIC_RESTAURANT_PAYMENT_URL || undefined,
  },
];

export async function getTemplates(): Promise<Template[]> {
  const c = sanity();
  if (!c) return TEMPLATES_FALLBACK;
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const docs: any[] = await c.fetch(`*[_type == "template" && defined(slug.current)] | order(coalesce(order, 999) asc) { title, "slug": slug.current, summary, features, demoUrl, cover, priceLabel, paymentUrl }`);
    if (!docs.length) return TEMPLATES_FALLBACK;
    return docs.map((d) => ({
      title: d.title,
      slug: d.slug,
      summary: d.summary || '',
      features: d.features || [],
      demoUrl: d.demoUrl || undefined,
      cover: imageUrl(d.cover, 1600) || undefined,
      priceLabel: d.priceLabel || undefined,
      paymentUrl: d.paymentUrl || undefined,
    }));
  } catch (err) {
    console.error('[templates] Sanity query failed:', err);
    return TEMPLATES_FALLBACK;
  }
}

export async function getTemplate(slug: string): Promise<Template | null> {
  const all = await getTemplates();
  return all.find((t) => t.slug === slug) || null;
}
