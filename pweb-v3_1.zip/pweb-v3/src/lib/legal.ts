export type LegalSection = { heading: string; content: string };
export type LegalDoc = { slug: string; title: string; lastUpdated: string; effectiveDate: string; version: string; summary: string; sections: LegalSection[] };

/** Copied unchanged from the previous site. These are drafts: have them reviewed before relying on them. */

export const legalDocs: Record<string, LegalDoc> = {
  privacy: {
    slug: 'privacy',
    title: 'Privacy Policy',
    lastUpdated: 'October 2026',
    effectiveDate: 'October 1, 2026',
    version: '1.0 (Draft)',
    summary: 'This Privacy Policy explains how P-Web Digitals collects, uses, and safeguards information when you visit our website or submit discovery briefs for studio engagements.',
    sections: [
      {
        heading: '1. Scope & Application',
        content: 'This policy applies to all visitors, clients, and prospective partners engaging with pwebdigitals.com and affiliated studio intake endpoints.'
      },
      {
        heading: '2. Information We Collect',
        content: 'We collect information you explicitly provide when submitting discovery intake briefs (name, work email, organization, technical scope description, and budget tiers). We do not collect unnecessary personal metrics or sell contact databases.'
      },
      {
        heading: '3. Technical & Operational Telemetry',
        content: 'We may record anonymous operational telemetry such as server logs, page performance metrics, and referrer headers to diagnose system latency, improve interface speed, and prevent abusive bot requests.'
      },
      {
        heading: '4. Data Retention & Safeguards',
        content: 'Client project briefs and communications are stored securely using encrypted transport and restricted internal access. We retain discovery submissions only as long as necessary to evaluate project feasibility and maintain communication.'
      },
      {
        heading: '5. Draft Notice',
        content: 'This document is a technical operating policy draft prepared for P-Web Digitals and will undergo formal jurisdictional legal review prior to commercial enterprise contract execution.'
      }
    ]
  },
  terms: {
    slug: 'terms',
    title: 'Terms of Service',
    lastUpdated: 'October 2026',
    effectiveDate: 'October 1, 2026',
    version: '1.0 (Draft)',
    summary: 'These Terms of Service govern the use of pwebdigitals.com and outline the architectural engagement parameters between P-Web Digitals and prospective clients.',
    sections: [
      {
        heading: '1. Studio Relationship',
        content: 'P-Web Digitals operates as a specialized digital systems and product studio. All commercial engineering projects, retainers, and software implementations are governed by separate, formally signed Scope of Work (SOW) agreements.'
      },
      {
        heading: '2. Intellectual Property',
        content: 'Unless otherwise agreed in a specific client contract, all studio proprietary frameworks, internal lab tooling (including SyncFlow), website source code, and design tokens remain the exclusive intellectual property of P-Web Digitals.'
      },
      {
        heading: '3. Submissions & Intake Scoping',
        content: 'Submitting a discovery brief does not establish a binding technical commitment until mutual scope alignment and formal contractual execution are confirmed by both parties.'
      },
      {
        heading: '4. Limitation of Liability',
        content: 'P-Web Digitals provides this website on an "as is" and "as available" basis without warranties of any kind regarding external third-party network interruptions or host uptime.'
      }
    ]
  },
  cookies: {
    slug: 'cookies',
    title: 'Cookie Notice & Preferences',
    lastUpdated: 'October 2026',
    effectiveDate: 'October 1, 2026',
    version: '1.0 (Draft)',
    summary: 'Information regarding how P-Web Digitals uses cookies and local browser storage to deliver a fast, responsive user experience.',
    sections: [
      {
        heading: '1. Essential Cookies',
        content: 'We use minimal essential session cookies and local storage tokens strictly required for site navigation, theme consistency, and intake state preservation.'
      },
      {
        heading: '2. Analytics & Performance',
        content: 'Anonymous analytics may measure Core Web Vitals, page transitions, and interface errors to help our engineers optimize delivery speed.'
      },
      {
        heading: '3. Zero Third-Party Advertising Trackers',
        content: 'P-Web Digitals does not deploy intrusive behavioral advertising cookies or third-party retargeting pixels across this website.'
      }
    ]
  },
  'refund-policy': {
    slug: 'refund-policy',
    title: 'Refund & Milestone Policy',
    lastUpdated: 'October 2026',
    effectiveDate: 'October 1, 2026',
    version: '1.0 (Draft)',
    summary: 'Details regarding billing milestones, deposit structures, and project cancellations for studio engagements.',
    sections: [
      {
        heading: '1. Milestone-Based Billing',
        content: 'All bespoke engineering projects, software MVPs, and growth implementations are delivered in structured milestones (e.g. Discovery/Architecture, Implementation, and Final Deployment).'
      },
      {
        heading: '2. Discovery & Setup Deposits',
        content: 'Initial discovery and architectural setup deposits cover dedicated engineering time and system blueprinting; deposits are non-refundable once architectural sprints have commenced.'
      },
      {
        heading: '3. Scope Adjustments & Cancellation',
        content: 'If an engagement is terminated before completion, the client is invoiced only for completed milestone deliverables and validated sprint hours, with work product transferred per agreement.'
      }
    ]
  },
  security: {
    slug: 'security',
    title: 'Security & Data Practices',
    lastUpdated: 'October 2026',
    effectiveDate: 'October 1, 2026',
    version: '1.0 (Draft)',
    summary: 'Our technical infrastructure standards, data isolation policies, and operational security posture.',
    sections: [
      {
        heading: '1. Transport & Encryption',
        content: 'All traffic between your browser and our services is encrypted via modern TLS protocols with strict HTTPS enforcement.'
      },
      {
        heading: '2. Webhook & API Isolation',
        content: 'Our event-driven webhook middleware and database relays utilize isolated environment variables, encrypted secrets storage, and HMAC signature verification to prevent spoofed event injections.'
      },
      {
        heading: '3. Responsible Disclosure',
        content: 'If you discover a technical vulnerability in any studio asset or prototype, please report it directly to security@pwebdigitals.com for immediate investigation.'
      }
    ]
  },
  accessibility: {
    slug: 'accessibility',
    title: 'Accessibility Statement',
    lastUpdated: 'October 2026',
    effectiveDate: 'October 1, 2026',
    version: '1.0 (Draft)',
    summary: 'Our commitment to engineering accessible, keyboard-friendly, and semantic web interfaces.',
    sections: [
      {
        heading: '1. Standards Alignment',
        content: 'We build toward WCAG 2.1 AA standards across color contrast, keyboard navigation, semantic HTML landmarks, and ARIA roles.'
      },
      {
        heading: '2. Reduced Motion Awareness',
        content: 'Our GSAP and CSS animations strictly honor the CSS prefers-reduced-motion media query, suppressing parallax, large translations, and transitions for users with vestibular sensitivities.'
      },
      {
        heading: '3. Feedback & Remediation',
        content: 'If you encounter any accessibility barrier on this website, please contact accessibility@pwebdigitals.com and our engineering team will address it promptly.'
      }
    ]
  },
  disclaimer: {
    slug: 'disclaimer',
    title: 'General Disclaimer',
    lastUpdated: 'October 2026',
    effectiveDate: 'October 1, 2026',
    version: '1.0 (Draft)',
    summary: 'Important informational and commercial disclosures regarding studio capabilities and performance expectations.',
    sections: [
      {
        heading: '1. No Guaranteed Commercial Outcomes',
        content: 'While we engineer high-performance systems and growth infrastructure, business growth depends on market demand, product-market fit, and operational execution. We do not manufacture synthetic revenue guarantees.'
      },
      {
        heading: '2. Case Studies & Technical Proof',
        content: 'All case studies, system architecture schematics, and project outcomes reflect genuine technical configurations and verified environments. Client names may be withheld for confidentiality reasons when requested.'
      }
    ]
  }
};

export function getLegalDocBySlug(slug: string): LegalDoc | undefined {
  return legalDocs[slug];
}
