import {
  Globe, Bot, Workflow, Rocket, Search, Clapperboard, Megaphone,
  BellRing, CalendarCheck, CalendarDays, ClipboardList, Code2, CreditCard, FileText, Gauge, KanbanSquare,
  LayoutDashboard, LayoutTemplate, Lightbulb, LineChart, MapPin, MessageCircle, MessageSquare, Mic,
  MousePointerClick, PencilLine, PhoneCall, Repeat, Smartphone, Sparkles, Star, UserRoundCheck, Wrench, Zap,
  Users, Handshake, Layers, Lock, Receipt, Briefcase,
  type LucideIcon,
} from 'lucide-react';

export { SERVICE_DATA } from './serviceData';

/** The seven services, in menu order. Copy for each service page lives in serviceData.ts. */
export const SERVICES: { href: string; slug: string; title: string; desc: string; Icon: LucideIcon }[] = [
  { href: '/web-design', slug: 'web-design', title: 'Web design', desc: 'Fast, phone-first websites that sell', Icon: Globe },
  { href: '/ai-automation', slug: 'ai-automation', title: 'AI automation & voice agents', desc: 'Chat, WhatsApp and phone agents', Icon: Bot },
  { href: '/crm-automation', slug: 'crm-automation', title: 'CRM & follow-up', desc: 'Booking, payments, reminders, reviews', Icon: Workflow },
  { href: '/lead-generation', slug: 'lead-generation', title: 'Funnels & lead generation', desc: 'Landing pages that turn clicks into enquiries', Icon: Megaphone },
  { href: '/seo', slug: 'seo', title: 'SEO', desc: 'Show up when people search', Icon: Search },
  { href: '/mvp-development', slug: 'mvp-development', title: 'MVPs & web apps', desc: 'Turn an idea into a working product', Icon: Rocket },
  { href: '/ai-video', slug: 'ai-video', title: 'AI video & editing', desc: 'Short-form video for your brand', Icon: Clapperboard },
];

/** Icon names used in serviceData.ts. */
export const ICONS: Record<string, LucideIcon> = {
  BellRing, CalendarCheck, CalendarDays, Clapperboard, ClipboardList, Code2, CreditCard, FileText, Gauge, KanbanSquare,
  LayoutDashboard, LayoutTemplate, Lightbulb, LineChart, MapPin, MessageCircle, MessageSquare, Mic, MousePointerClick,
  PencilLine, PhoneCall, Repeat, Rocket, Search, Smartphone, Sparkles, Star, UserRoundCheck, Wrench, Zap,
  Users, Handshake, Layers, Lock, Receipt, Briefcase, Globe, Bot, Workflow, Megaphone,
};
