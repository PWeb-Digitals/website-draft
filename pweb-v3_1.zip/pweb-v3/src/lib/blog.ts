import type { PortableTextBlock } from '@portabletext/react';
import { sanity, imageUrl } from './sanity';

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  coverImage: string;
  coverAlt: string;
  publishedDate: string;
  updatedDate: string;
  category: string;
  readTime: string;
  author: { name: string; role: string; avatar: string };
  seoTitle?: string;
  seoDescription?: string;
  body?: PortableTextBlock[];
  published: boolean;
}

const AUTHOR = { name: 'Peace Azubuike', role: 'Founder, P-Web Digitals', avatar: '/images/peace-azubuike.jpg' };
const FALLBACK_COVER = '/images/og.jpg';

const FIELDS = `
  _id, title, "slug": slug.current, excerpt, category, publishedAt, _updatedAt,
  coverImage, "coverAlt": coverImage.alt, seoTitle, seoDescription,
  "words": length(pt::text(body))
`;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function toPost(d: any, withBody = false): BlogPost {
  const chars = Number(d.words || 0);
  const minutes = Math.max(1, Math.round(chars / 5 / 220));
  return {
    id: d._id,
    title: d.title || 'Untitled',
    slug: d.slug,
    excerpt: d.excerpt || '',
    coverImage: imageUrl(d.coverImage, 1600) || FALLBACK_COVER,
    coverAlt: d.coverAlt || d.title || '',
    publishedDate: (d.publishedAt || d._updatedAt || '').slice(0, 10),
    updatedDate: (d._updatedAt || d.publishedAt || '').slice(0, 10),
    category: d.category || 'Insights',
    readTime: `${minutes} min read`,
    author: AUTHOR,
    seoTitle: d.seoTitle || undefined,
    seoDescription: d.seoDescription || undefined,
    body: withBody ? d.body || [] : undefined,
    published: true,
  };
}

/** Published posts, newest first. Returns [] (never fake posts) if Sanity isn't set up or fails. */
export async function getAllPublishedPosts(): Promise<BlogPost[]> {
  const c = sanity();
  if (!c) return [];
  try {
    const docs = await c.fetch(
      `*[_type == "post" && defined(slug.current) && publishedAt <= now()] | order(publishedAt desc) { ${FIELDS} }`
    );
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return (docs as any[]).map((d) => toPost(d));
  } catch (err) {
    console.error('[blog] Sanity query failed:', err);
    return [];
  }
}

export async function getPostBySlug(slug: string): Promise<BlogPost | null> {
  const c = sanity();
  if (!c) return null;
  try {
    const d = await c.fetch(
      `*[_type == "post" && slug.current == $slug && publishedAt <= now()][0] { ${FIELDS}, body[]{ ..., _type == "image" => { ..., "url": asset->url, "dims": asset->metadata.dimensions } } }`,
      { slug }
    );
    return d ? toPost(d, true) : null;
  } catch (err) {
    console.error('[blog] Sanity query failed:', err);
    return null;
  }
}
