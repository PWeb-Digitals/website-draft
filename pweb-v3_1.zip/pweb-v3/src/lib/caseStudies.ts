/**
 * The three older case-study pages (kept so their URLs keep working).
 * Reworded in plain language from the previous site. They are in-house builds and work in progress,
 * and they say so. Replace or remove them when real client case studies are ready.
 */
export type CaseStudy = { slug: string; title: string; status: string; summary: string; problem: string; approach: string; flow: string[]; tools: string[]; outcome: string; image?: string; related: string[] };

export const CASE_STUDIES: CaseStudy[] = [
  {
    slug: 'unified-growth-intake-engine',
    title: 'Every enquiry in one CRM pipeline',
    status: 'In progress',
    summary: 'Bringing enquiries from WhatsApp, landing pages and email into one pipeline, with instant follow-up.',
    problem: 'Enquiries were scattered across WhatsApp, separate landing pages and email inboxes. Replies were slow and nobody could see which campaign a lead came from.',
    approach: 'Every form and message now goes to one place. New leads land in a CRM pipeline and get a WhatsApp or SMS reply within about two minutes.',
    flow: ['Landing page or message', 'Lead details captured', 'Added to the CRM pipeline', 'Instant WhatsApp or SMS reply', 'Stage updated as the lead moves'],
    tools: ['Framer', 'Your CRM', 'n8n', 'WhatsApp Business', 'Stripe'],
    outcome: 'Still being tested before launch. We will publish results once it has been running with real leads.',
    image: '/images/multi-channel-crm-pipeline.jpg',
    related: ['crm-automation', 'lead-generation'],
  },
  {
    slug: 'syncflow-payment-automation',
    title: 'Payments that update the CRM on their own',
    status: 'In-house prototype',
    summary: 'A prototype that connects Paystack and Stripe checkouts to the CRM, sends receipts and gives customers access straight away.',
    problem: 'When someone pays online, the receipt, CRM update and customer access usually happen by hand, so customers wait and records go out of date.',
    approach: 'A payment confirmation from Paystack or Stripe triggers an automation that tags the customer in the CRM, sends the receipt and starts onboarding.',
    flow: ['Customer pays (Paystack or Stripe)', 'Payment confirmation received', 'Customer tagged in the CRM', 'Receipt and welcome sent', 'Access or onboarding starts'],
    tools: ['Make', 'n8n', 'Your CRM', 'Stripe', 'Paystack', 'Airtable'],
    outcome: 'Working as a prototype in our own testing. Not yet running for a client.',
    image: '/images/syncflow-invoice-automation.png',
    related: ['crm-automation', 'ai-automation'],
  },
  {
    slug: 'ai-short-form-video-pipeline',
    title: 'A repeatable short-form video process',
    status: 'In use in the studio',
    summary: 'How we turn long recordings into captioned short videos for Reels, TikTok and YouTube Shorts.',
    problem: 'Cutting long videos into short clips, adding captions and exporting for each platform takes hours every week.',
    approach: 'A set process: transcribe, pick the strongest moments, cut, add animated captions, then fix colour and sound before exporting each format.',
    flow: ['Long recording', 'Transcript with timestamps', 'Best moments picked', 'Captions added', 'Colour and sound finished', '9:16 and 16:9 exports'],
    tools: ['CapCut', 'Premiere Pro', 'Descript', 'ElevenLabs'],
    outcome: 'We use this process for our own content and client edits.',
    related: ['ai-video'],
  },
];
