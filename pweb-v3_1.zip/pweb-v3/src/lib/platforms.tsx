import type { IconType } from 'react-icons';
import {
  SiWhatsapp, SiN8N, SiMake, SiZapier, SiStripe, SiPaypal, SiCaldotcom, SiGooglecalendar, SiGmail,
  SiHubspot, SiAnthropic, SiElevenlabs, SiTelegram, SiInstagram, SiShopify, SiWordpress,
  SiWebflow, SiFramer, SiFigma, SiNextdotjs, SiVercel, SiGoogleanalytics, SiGooglesearchconsole,
  SiNotion, SiAirtable, SiMailchimp, SiBrevo, SiSanity, SiGoogle,
} from 'react-icons/si';
import { LuWorkflow } from 'react-icons/lu';

export type Platform = { name: string; Icon?: IconType; img?: string; color: string };

/** Simple stacked-bars mark for Paystack (react-icons has no Paystack icon). */
const PaystackIcon: IconType = ({ size = 22, color = '#00C3F7' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true">
    <rect x="2" y="3" width="20" height="3.6" rx="1.4" fill={color} />
    <rect x="2" y="8.6" width="20" height="3.6" rx="1.4" fill={color} />
    <rect x="2" y="14.2" width="12" height="3.6" rx="1.4" fill={color} />
    <rect x="2" y="19.6" width="20" height="2.4" rx="1.2" fill={color} opacity=".55" />
  </svg>
);

/** Paystack has no icon in react-icons, so it renders as a lettermark. */
export const P: Record<string, Platform> = {
  whatsapp: { name: 'WhatsApp', Icon: SiWhatsapp, color: '#25D366' },
  n8n: { name: 'n8n', Icon: SiN8N, color: '#EA4B71' },
  make: { name: 'Make', Icon: SiMake, color: '#A855F7' },
  zapier: { name: 'Zapier', Icon: SiZapier, color: '#FF4F00' },
  stripe: { name: 'Stripe', Icon: SiStripe, color: '#635BFF' },
  paypal: { name: 'PayPal', Icon: SiPaypal, color: '#00A2FF' },
  paystack: { name: 'Paystack', Icon: PaystackIcon, color: '#00C3F7' },
  cal: { name: 'Cal.com', Icon: SiCaldotcom, color: '#ffffff' },
  gcal: { name: 'Google Calendar', Icon: SiGooglecalendar, color: '#4285F4' },
  gmail: { name: 'Gmail', Icon: SiGmail, color: '#EA4335' },
  hubspot: { name: 'HubSpot', Icon: SiHubspot, color: '#FF7A59' },
  ghl: { name: 'Your CRM', Icon: LuWorkflow, color: '#c0e6fd' },
  openai: { name: 'OpenAI', color: '#ffffff' },
  claude: { name: 'Claude', Icon: SiAnthropic, color: '#D97757' },
  elevenlabs: { name: 'ElevenLabs', Icon: SiElevenlabs, color: '#ffffff' },
  vapi: { name: 'Vapi', color: '#5DFECA' },
  telegram: { name: 'Telegram', Icon: SiTelegram, color: '#26A5E4' },
  instagram: { name: 'Instagram', Icon: SiInstagram, color: '#E4405F' },
  shopify: { name: 'Shopify', Icon: SiShopify, color: '#95BF47' },
  wordpress: { name: 'WordPress', Icon: SiWordpress, color: '#ffffff' },
  webflow: { name: 'Webflow', Icon: SiWebflow, color: '#4353FF' },
  framer: { name: 'Framer', Icon: SiFramer, color: '#ffffff' },
  figma: { name: 'Figma', Icon: SiFigma, color: '#F24E1E' },
  nextjs: { name: 'Next.js', Icon: SiNextdotjs, color: '#ffffff' },
  vercel: { name: 'Vercel', Icon: SiVercel, color: '#ffffff' },
  ga: { name: 'Google Analytics', Icon: SiGoogleanalytics, color: '#F9AB00' },
  gsc: { name: 'Search Console', Icon: SiGooglesearchconsole, color: '#458CF5' },
  google: { name: 'Google', Icon: SiGoogle, color: '#4285F4' },
  notion: { name: 'Notion', Icon: SiNotion, color: '#ffffff' },
  airtable: { name: 'Airtable', Icon: SiAirtable, color: '#18BFFF' },
  mailchimp: { name: 'Mailchimp', Icon: SiMailchimp, color: '#FFE01B' },
  brevo: { name: 'Brevo', Icon: SiBrevo, color: '#0B996E' },
  sanity: { name: 'Sanity', Icon: SiSanity, color: '#F03E2F' },
};

export function PlatformIcon({ p, size = 22 }: { p: Platform; size?: number }) {
  if (p.Icon) return <p.Icon size={size} color={p.color} aria-hidden="true" />;
  if (p.img) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={p.img} alt="" width={size} height={size} style={{ width: size, height: size, objectFit: 'contain' }} />;
  }
  return (
    <span aria-hidden="true" className="mono" style={{ fontSize: size * 0.62, fontWeight: 700, color: p.color, lineHeight: 1 }}>
      {p.name.slice(0, 2)}
    </span>
  );
}

export function PlatformChip({ p }: { p: Platform }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-[var(--line)] bg-[rgba(16,37,66,0.6)] px-3 py-1.5 text-[13px] text-[var(--text)]">
      <PlatformIcon p={p} size={15} />
      {p.name}
    </span>
  );
}
