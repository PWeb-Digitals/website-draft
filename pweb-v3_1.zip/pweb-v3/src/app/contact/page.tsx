import { SiWhatsapp } from 'react-icons/si';
import { Mail, CalendarCheck } from 'lucide-react';
import { pageMeta, SITE } from '@/lib/site';
import { PageHero } from '@/components/PageHero';
import { ContactForm } from '@/components/ContactForm';

export const metadata = pageMeta('/contact', 'Contact Us', 'Tell us what you want to build. Send a message and Peace replies within one working day, or book a call or message us on WhatsApp.');

export default function ContactPage() {
  return (
    <>
      <PageHero label="Contact" title="Tell us what you want to build." sub="Fill in the form and we'll reply within one working day. Prefer to talk? Book a call or message us on WhatsApp." />
      <section className="container section" style={{ paddingTop: 0 }}>
        <div className="contact-grid">
          <div className="contact-side">
            <a href={SITE.whatsapp} target="_blank" rel="noopener" className="tile-card dark" data-reveal>
              <span className="tc-ico"><SiWhatsapp size={18} /></span>
              <div><h2>WhatsApp</h2><p>{SITE.whatsappLabel}</p></div>
            </a>
            <a href="/book" className="tile-card" data-reveal>
              <span className="tc-ico"><CalendarCheck size={18} strokeWidth={1.5} /></span>
              <div><h2>Book a call</h2><p>Pick a 30-minute slot that suits you.</p></div>
            </a>
            <a href={`mailto:${SITE.email}`} className="tile-card" data-reveal>
              <span className="tc-ico"><Mail size={18} strokeWidth={1.5} /></span>
              <div><h2>Email</h2><p>{SITE.email}</p></div>
            </a>
          </div>
          <div className="form-card" data-reveal>
            <ContactForm />
          </div>
        </div>
      </section>
    </>
  );
}
