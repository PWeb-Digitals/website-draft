import { Hero } from '@/components/Hero';
import { Struggle } from '@/components/Struggle';
import { How } from '@/components/How';
import { Integration } from '@/components/Integration';
import { Approach, InstaWall } from '@/components/Social';
import { Showcase } from '@/components/Showcase';
import { Pricing } from '@/components/Pricing';
import { Founder, AuditBlock, Faq, Cta } from '@/components/Bottom';
import { getProjects } from '@/lib/content';
import { getInstagramPosts } from '@/lib/instagram';

export const revalidate = 3600;

export default async function Home() {
  const [projects, posts] = await Promise.all([getProjects(), getInstagramPosts(12)]);
  return (
    <>
      <Hero />
      <Struggle />
      <How />
      <Integration />
      <Approach />
      <InstaWall posts={posts} />
      <Showcase items={projects} />
      <Pricing />
      <Founder />
      <AuditBlock />
      <Faq />
      <Cta />
    </>
  );
}
