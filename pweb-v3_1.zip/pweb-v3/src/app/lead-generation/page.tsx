import { ServicePage } from '@/components/ServicePage';
import { pageMeta } from '@/lib/site';

export const metadata = pageMeta('/lead-generation', 'Landing Pages, Funnels & Lead Generation', 'Landing pages, lead forms and offers built to convert, connected to instant follow-up so no enquiry goes cold.');

export default function Page() {
  return <ServicePage slug="lead-generation" />;
}
