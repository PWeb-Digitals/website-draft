import { NextRequest, NextResponse } from 'next/server';

/**
 * One endpoint for every form on the site: contact, website audit, template brief and newsletter.
 * 1. Sends the lead to your n8n webhook (LEAD_WEBHOOK_URL). n8n adds it to Kit with the right tag,
 *    runs the PageSpeed check for audits and pings you on Telegram.
 * 2. Emails you a copy (GMAIL_USER + GMAIL_APP_PASSWORD), so nothing is lost if n8n is down.
 */
const PATHWAYS = ['contact', 'website-audit', 'template-brief', 'newsletter'];

const esc = (v: string) => v.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] as string));

/** The notification email is HTML, so escape what visitors typed and fold the extra fields into the message. */
function emailCopy(lead: Record<string, string | undefined>) {
  const extra = [`Form: ${lead.pathway}`, `Website: ${lead.website}`, lead.template ? `Template: ${lead.template}` : '', `Page: ${lead.source}`].filter(Boolean).join('\n');
  return {
    name: esc(lead.name || ''),
    email: esc(lead.email || ''),
    phone: esc(lead.phone || ''),
    organization: esc(lead.organization || ''),
    pathway: esc(lead.pathway || ''),
    bottleneck: esc(`${lead.bottleneck}\n\n${extra}`),
    budget: esc(lead.budget || ''),
    submittedAt: lead.submittedAt,
    source: esc(lead.source || ''),
  };
}

export async function POST(req: NextRequest) {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  let body: any = {};
  try { body = await req.json(); } catch { /* empty */ }

  const str = (v: unknown, max = 2000) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
  const name = str(body.name, 120);
  const email = str(body.email, 200);
  const pathway = PATHWAYS.includes(body.pathway) ? body.pathway : 'contact';

  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return NextResponse.json({ error: 'A valid email is required.' }, { status: 400 });
  }
  if (pathway !== 'newsletter' && !name) {
    return NextResponse.json({ error: 'Your name is required.' }, { status: 400 });
  }
  if (pathway === 'website-audit' && !str(body.website)) {
    return NextResponse.json({ error: 'Your website URL is required for the audit.' }, { status: 400 });
  }
  // Simple bot trap: the hidden "company" field must stay empty.
  if (str(body.company)) return NextResponse.json({ success: true });

  const lead = {
    name: name || email.split('@')[0],
    email,
    phone: str(body.phone, 60) || 'Not provided',
    website: str(body.website, 300) || 'Not provided',
    organization: str(body.business, 200) || 'Not specified',
    pathway,
    template: str(body.template, 80) || undefined,
    bottleneck: str(body.message, 4000) || 'Not provided',
    budget: str(body.budget, 80) || 'Not specified',
    source: str(body.page, 200) || 'pwebdigitals.com',
    submittedAt: new Date().toISOString(),
  };

  const webhook = process.env.LEAD_WEBHOOK_URL || process.env.N8N_WEBHOOK_URL;
  const jobs: Promise<unknown>[] = [];
  if (webhook) {
    jobs.push(
      fetch(webhook, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(lead) })
        .catch((err) => console.error('[contact] webhook failed:', err)),
    );
  }
  if (pathway !== 'newsletter') {
    jobs.push(
      import('@/lib/emailService')
        .then(({ sendLeadNotificationEmail }) => sendLeadNotificationEmail(emailCopy(lead)))
        .catch((err) => console.error('[contact] email failed:', err)),
    );
  }
  await Promise.all(jobs);

  if (!webhook && pathway === 'newsletter') {
    console.warn('[contact] LEAD_WEBHOOK_URL is not set, so this newsletter signup was not saved anywhere.');
  }
  return NextResponse.json({ success: true });
}
