import { NextRequest } from 'next/server';
import { POST as contact } from '../contact/route';

/** Kept for old links: forwards to /api/contact as a newsletter signup. */
export async function POST(req: NextRequest) {
  let body: Record<string, unknown> = {};
  try { body = await req.json(); } catch { /* empty */ }
  const forward = new NextRequest(req.url, { method: 'POST', body: JSON.stringify({ ...body, pathway: 'newsletter' }), headers: { 'Content-Type': 'application/json' } });
  return contact(forward);
}
