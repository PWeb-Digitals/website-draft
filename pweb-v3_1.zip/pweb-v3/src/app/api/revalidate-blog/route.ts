import { NextRequest, NextResponse } from 'next/server';
import { revalidatePath } from 'next/cache';

/**
 * Sanity calls this every time you publish, update or delete a post, project or template.
 * It refreshes only the pages that use that content, so no Netlify deploy is needed.
 *
 * Sanity webhook settings (sanity.io/manage > API > Webhooks):
 *   URL:         https://pwebdigitals.com/api/revalidate-blog?secret=YOUR_SECRET
 *   Dataset:     production
 *   Trigger on:  Create, Update, Delete
 *   Filter:      _type in ["post", "project", "template"]
 *   Projection:  {"type": _type, "slug": slug.current}
 *   HTTP method: POST
 * YOUR_SECRET must match REVALIDATION_SECRET in Netlify's environment variables.
 */
async function handle(request: NextRequest) {
  const expected = process.env.REVALIDATION_SECRET;
  if (!expected) return NextResponse.json({ message: 'REVALIDATION_SECRET is not set on the server' }, { status: 500 });
  const secret = request.nextUrl.searchParams.get('secret') || request.headers.get('x-revalidate-secret');
  if (secret !== expected) return NextResponse.json({ message: 'Invalid secret' }, { status: 401 });

  let type = 'post';
  let slug: string | undefined;
  try {
    const body = await request.json();
    if (typeof body?.type === 'string') type = body.type;
    if (typeof body?.slug === 'string') slug = body.slug;
  } catch { /* GET or empty body */ }

  if (type === 'project') {
    revalidatePath('/work');
    revalidatePath('/');
  } else if (type === 'template') {
    revalidatePath('/templates');
    if (slug) revalidatePath(`/templates/${slug}`);
    else revalidatePath('/templates/[slug]', 'page');
  } else {
    revalidatePath('/blog');
    if (slug) revalidatePath(`/blog/${slug}`);
    else revalidatePath('/blog/[slug]', 'page');
  }
  revalidatePath('/sitemap.xml');
  return NextResponse.json({ revalidated: true, type, slug: slug ?? 'all', now: Date.now() });
}

export const POST = handle;
export const GET = handle;
