import { notFound } from 'next/navigation';
import Image from 'next/image';
import { getTemplate, getTemplates } from '@/lib/content';
import { pageMeta } from '@/lib/site';
import { PageHero, SecIntro } from '@/components/PageHero';
import { ContactForm } from '@/components/ContactForm';
import { Faq } from '@/components/Bottom';
import { Btn, Check } from '@/components/ui';

export const revalidate = 3600;

export async function generateStaticParams() {
  return (await getTemplates()).map((t) => ({ slug: t.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const t = await getTemplate(slug);
  if (!t) return {};
  return pageMeta(`/templates/${t.slug}`, `${t.title} Website Template`, t.summary, t.cover);
}

const FAQS = [
  { q: 'Is this a file I download?', a: 'No. We build your version for you, with your name, menu or services, photos, prices and payment details, and launch it on your domain.' },
  { q: 'How does payment work?', a: 'After you send your brief you pay a deposit by Paystack. You get the full price and payment terms in writing first.' },
  { q: 'Can I change the design?', a: 'Yes. Colours, fonts, photos and sections are adjusted to your brand. Bigger changes are quoted before we start.' },
];

export default async function TemplatePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const t = await getTemplate(slug);
  if (!t) notFound();
  return (
    <>
      <PageHero crumbs={[{ href: '/templates', t: 'Templates' }, { href: `/templates/${t.slug}`, t: t.title }]} title={`${t.title} website, ready for your business.`} sub={t.summary}>
        {t.demoUrl ? <Btn href={t.demoUrl} variant="dark" size="lg" icon="upright">Open the live demo</Btn> : null}
        <Btn href="#brief" size="lg">Get this built</Btn>
      </PageHero>

      <section className="container" data-reveal>
        <div className="tpl-preview" style={{ maxWidth: 1032, marginInline: 'auto' }}>
          {t.demoUrl ? (
            <iframe src={t.demoUrl} title={`${t.title} template live demo`} loading="lazy" />
          ) : t.cover ? (
            <Image src={t.cover} alt={`${t.title} template`} fill sizes="(min-width: 1080px) 1032px, 92vw" />
          ) : (
            <div className="tp-empty"><p>The live demo link will appear here once it&apos;s published.</p></div>
          )}
        </div>
      </section>

      <section className="section container" id="brief">
        <div className="contact-grid">
          <div>
            <SecIntro label="What it does" title="Everything switched on." sub={t.priceLabel ? `${t.priceLabel}. Fixed price in writing before you pay.` : 'Price on request. You get a fixed price in writing before you pay.'} />
            <ul className="tpl-features">{t.features.map((f) => <li key={f}><Check />{f}</li>)}</ul>
          </div>
          <div className="form-card" data-reveal>
            <h2 className="t-h3" style={{ fontWeight: 600, marginBottom: 6 }}>Send your brief</h2>
            <p className="t-body" style={{ fontSize: 14, marginBottom: 16 }}>{t.paymentUrl ? 'After you send it, you’ll go to Paystack to pay the deposit.' : 'We’ll reply with a fixed price and a Paystack link for the deposit.'}</p>
            <ContactForm template={t.title} paymentUrl={t.paymentUrl} />
          </div>
        </div>
      </section>

      <Faq items={FAQS} title="Questions" />
    </>
  );
}
