import Link from 'next/link';
import Image from 'next/image';
import { UtensilsCrossed, Plus } from 'lucide-react';
import { getTemplates } from '@/lib/content';
import { pageMeta } from '@/lib/site';
import { PageHero } from '@/components/PageHero';
import { Cta } from '@/components/Bottom';
import { ArrowUpRight } from '@/components/ui';

export const revalidate = 3600;
export const metadata = pageMeta('/templates', 'Website Templates by Industry', 'Live website demos for your industry, with ordering, booking and payments switched on. Pick one, send your brief, and we build your version.');

export default async function TemplatesPage() {
  const templates = await getTemplates();
  return (
    <>
      <PageHero label="Templates" title="See it working for your industry, before you pay." sub="Each template is a full working demo with ordering, booking and payments switched on. Like one? Send us your brief, pay the deposit, and we build your version." />
      <section className="container section" style={{ paddingTop: 0 }}>
        <div className="grid-2">
          {templates.map((t, i) => (
            <Link key={t.slug} href={`/templates/${t.slug}`} className={`tile-card${i === 0 ? ' dark' : ''}`} data-reveal style={{ minHeight: 380 }}>
              {t.cover ? (
                <div className="tpl-preview" style={{ aspectRatio: '16 / 9' }}><Image src={t.cover} alt={`${t.title} template`} fill sizes="(min-width: 860px) 520px, 92vw" /></div>
              ) : (
                <span className="tc-ico"><UtensilsCrossed size={18} strokeWidth={1.5} /></span>
              )}
              <span className="tc-go"><ArrowUpRight /></span>
              <div>
                <h2>{t.title}</h2>
                <p>{t.summary}</p>
                {t.priceLabel && <p style={{ marginTop: 12, color: 'inherit', fontWeight: 600 }}>{t.priceLabel}</p>}
              </div>
            </Link>
          ))}
          <Link href="/contact" className="tile-card" data-reveal style={{ minHeight: 380 }}>
            <span className="tc-ico"><Plus size={18} strokeWidth={1.5} /></span>
            <span className="tc-go"><ArrowUpRight /></span>
            <div>
              <h2>Your industry next?</h2>
              <p>Tell us what kind of business you run and we&apos;ll show you what your version could look like.</p>
            </div>
          </Link>
        </div>
        <ol className="steps" style={{ marginTop: 40 }}>
          <li>Pick a template and try the live demo.</li>
          <li>Send us a short brief about your business.</li>
          <li>Pay the deposit securely by Paystack.</li>
          <li>We build, you review, and it goes live on your domain.</li>
        </ol>
      </section>
      <Cta />
    </>
  );
}
