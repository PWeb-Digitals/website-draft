import { ServicePage } from '@/components/ServicePage';
import { pageMeta } from '@/lib/site';

export const metadata = pageMeta('/ai-video', 'AI Video Production & Short-Form Editing', 'Short-form video and AI-assisted editing for your brand: ads, explainers and Reels, TikToks and Shorts ready to post.');

export default function Page() {
  return <ServicePage slug="ai-video" />;
}
