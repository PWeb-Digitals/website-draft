import { pageMeta } from '@/lib/site';
import { PageHero } from '@/components/PageHero';
import { Pricing } from '@/components/Pricing';
import { Faq, Cta, HOME_FAQS } from '@/components/Bottom';
import { Btn } from '@/components/ui';

export const metadata = pageMeta('/pricing', 'Website & Automation Pricing', 'Clear prices for websites, funnels, CRM setup and AI agents. Every project gets a fixed scope and price in writing before work starts. Pay in USD or naira.');

export default function PricingPage() {
  return (
    <>
      <PageHero label="Pricing" title="Clear prices. No surprises." sub="Every project gets a fixed scope and price in writing before work starts. Pay in dollars or naira; naira prices use the exchange rate on the day you accept the quote.">
        <Btn href="/book" variant="dark" size="lg">Get a fixed quote</Btn>
      </PageHero>
      <Pricing heading="Pick a starting point." />
      <Faq items={HOME_FAQS} />
      <Cta />
    </>
  );
}
