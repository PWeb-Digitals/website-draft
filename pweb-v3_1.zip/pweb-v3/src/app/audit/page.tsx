import { pageMeta } from '@/lib/site';
import { PageHero } from '@/components/PageHero';
import { AuditForm } from '@/components/AuditForm';
import { FeatureGrid } from '@/components/FeatureGrid';

export const metadata = pageMeta('/audit', 'Free Website Audit', 'Send your website link and get a free audit by email: speed, how it works on a phone, Google basics and what happens after someone gets in touch.');

const CHECKS = [
  { t: 'Speed', d: 'How long your pages take to show on a mid-range phone, and what is slowing them down.', icon: 'Gauge' },
  { t: 'Phone experience', d: 'Whether buttons, menus and forms are easy to use on a small screen.', icon: 'Smartphone' },
  { t: 'Google basics', d: 'Titles, descriptions, indexing and your Google Business Profile.', icon: 'Search' },
  { t: 'After the enquiry', d: 'What happens when someone fills your form or sends a message, and how fast they hear back.', icon: 'Zap' },
];

export default function AuditPage() {
  return (
    <>
      <PageHero label="Free website audit" title="Where is your website losing customers?" sub="Send us your link. We check it and email you what to fix first. No call needed." />
      <section className="container" style={{ paddingBottom: 40 }}>
        <div className="form-card" style={{ maxWidth: 560, marginInline: 'auto' }} data-reveal>
          <AuditForm />
        </div>
      </section>
      <section className="section">
        <FeatureGrid items={CHECKS} />
      </section>
    </>
  );
}
