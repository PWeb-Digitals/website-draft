import { ServicePage } from '@/components/ServicePage';
import { pageMeta } from '@/lib/site';

export const metadata = pageMeta('/crm-automation', 'CRM Setup, Booking & Automated Follow-Up', 'One pipeline for every lead, with booking, payments, reminders and review requests that run on their own. Set up for how your business sells.');

export default function Page() {
  return <ServicePage slug="crm-automation" />;
}
