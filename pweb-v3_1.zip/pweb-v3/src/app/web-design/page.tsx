import { ServicePage } from '@/components/ServicePage';
import { pageMeta } from '@/lib/site';

export const metadata = pageMeta('/web-design', 'Web Design & Conversion-Focused Websites', 'Custom websites designed on a phone screen first, quick to load and clear to read, with booking, payments and follow-up built in.');

export default function Page() {
  return <ServicePage slug="web-design" />;
}
