import Image from 'next/image';
import { pageMeta } from '@/lib/site';
import { PageHero, SecIntro } from '@/components/PageHero';
import { FeatureGrid } from '@/components/FeatureGrid';
import { AuditBlock, Cta } from '@/components/Bottom';
import { Btn } from '@/components/ui';

export const metadata = pageMeta('/about', 'About P-Web & Founder Peace Azubuike', 'P-Web Digitals is the founder-led web design and automation studio of Peace Azubuike in Akure, Nigeria, working with businesses in Nigeria and worldwide.');

const PRINCIPLES = [
  { t: 'You talk to me', d: 'Every project goes through me personally, from the first call to the handover.', icon: 'MessageCircle' },
  { t: 'You own everything', d: 'Your domain, files and logins stay in your name.', icon: 'UserRoundCheck' },
  { t: 'Phone first', d: 'Most of your customers are on a phone, so every layout starts there.', icon: 'Smartphone' },
  { t: 'Agreed up front', d: 'A clear scope and a fixed price before any work starts.', icon: 'FileText' },
];

export default function AboutPage() {
  return (
    <>
      <PageHero label="About" title="Hi, I'm Peace. I build websites and systems that sell." sub="P-Web Digitals is my studio in Akure, Nigeria. We work with businesses in Nigeria and around the world.">
        <Btn href="/book" variant="dark" size="lg">Book a call with me</Btn>
      </PageHero>
      <section className="founders" style={{ paddingTop: 100, paddingBottom: 100 }}>
        <div className="fd-inner fd-two container">
          <figure className="fd-person" data-reveal>
            <div className="portrait"><Image src="/images/peace-azubuike.jpg" alt="Peace Azubuike, founder of P-Web Digitals" fill sizes="(min-width: 860px) 320px, 70vw" priority /></div>
            <figcaption><span className="g">Peace</span> Azubuike<small>Founder, P-Web Digitals</small></figcaption>
          </figure>
          <div className="fd-copy" data-reveal>
            <p className="t-label" style={{ color: 'var(--grey-2)' }}>The short version</p>
            <h2 className="t-h2">Most business websites look fine and bring in nothing.</h2>
            <p>I started P-Web to fix that: a good website, connected to the replies, booking, payments and follow-up that turn visitors into paying customers.</p>
          </div>
        </div>
      </section>
      <section className="section">
        <div className="container"><SecIntro center label="How I work" title="Four things you can count on." /></div>
        <FeatureGrid items={PRINCIPLES} />
      </section>
      <AuditBlock />
      <Cta />
    </>
  );
}
