import Image from 'next/image';
import { notFound } from 'next/navigation';
import { CASE_STUDIES } from '@/lib/caseStudies';
import { SERVICES } from '@/lib/services';
import { pageMeta } from '@/lib/site';
import { PageHero } from '@/components/PageHero';
import { Cta } from '@/components/Bottom';
import { Btn, Check } from '@/components/ui';

export const dynamicParams = false;
export function generateStaticParams() {
  return CASE_STUDIES.map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const c = CASE_STUDIES.find((x) => x.slug === slug);
  if (!c) return {};
  return pageMeta(`/work/${c.slug}`, `${c.title} | Case Study`, c.summary, c.image);
}

export default async function CaseStudyPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const c = CASE_STUDIES.find((x) => x.slug === slug);
  if (!c) notFound();
  const related = SERVICES.filter((s) => c.related.includes(s.slug));
  return (
    <>
      <PageHero crumbs={[{ href: '/work', t: 'Work' }, { href: `/work/${c.slug}`, t: c.title }]} title={c.title} sub={c.summary}>
        <span className="work-tag">{c.status}</span>
      </PageHero>
      {c.image && (
        <section className="container" data-reveal>
          <div className="work-shot" style={{ maxWidth: 960, marginInline: 'auto' }}><Image src={c.image} alt={c.title} fill sizes="(min-width: 1000px) 960px, 92vw" /></div>
        </section>
      )}
      <section className="section container">
        <div className="grid-2">
          <div className="tile-card" data-reveal><div><p className="t-label">The problem</p><p style={{ marginTop: 12, fontSize: 17, color: 'var(--black)' }}>{c.problem}</p></div></div>
          <div className="tile-card" data-reveal><div><p className="t-label">What we built</p><p style={{ marginTop: 12, fontSize: 17, color: 'var(--black)' }}>{c.approach}</p></div></div>
        </div>
        <div className="include-card" style={{ marginTop: 24 }} data-reveal>
          <div>
            <p className="t-label" style={{ color: 'var(--grey-2)' }}>How it flows</p>
            <h2 className="t-h2" style={{ marginTop: 12 }}>Step by step.</h2>
            <p>{c.outcome}</p>
            <p style={{ marginTop: 16 }}>Tools: {c.tools.join(', ')}</p>
          </div>
          <ul>{c.flow.map((f) => <li key={f}><Check />{f}</li>)}</ul>
        </div>
        <div className="ph-actions" style={{ marginTop: 40 }}>
          {related.map((r) => <Btn key={r.href} href={r.href}>{r.title}</Btn>)}
          <Btn href="/work">All work</Btn>
        </div>
      </section>
      <Cta />
    </>
  );
}
