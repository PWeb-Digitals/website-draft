import Image from 'next/image';
import { getProjects } from '@/lib/content';
import { pageMeta } from '@/lib/site';
import { PageHero } from '@/components/PageHero';
import { Cta } from '@/components/Bottom';
import { Btn } from '@/components/ui';

export const revalidate = 3600;
export const metadata = pageMeta('/work', 'Selected Work: Websites & Systems We Built', 'Live websites, online stores and booking systems designed and built by P-Web Digitals for clients in Nigeria, the UK, the US and beyond.');

export default async function WorkPage() {
  const projects = await getProjects();
  return (
    <>
      <PageHero label="Selected work" title="Real sites, built by us and live now." sub="A few of the websites and systems we have designed and built for clients.">
        <Btn href="/book" variant="dark" size="lg">Start your project</Btn>
      </PageHero>
      <section className="container section" style={{ paddingTop: 0 }}>
        <div className="work-list">
          {projects.map((p) => (
            <article key={p.slug} className="work-row" data-reveal>
              <div className="work-shot"><Image src={p.img} alt={`${p.name} website`} fill sizes="(min-width: 860px) 640px, 92vw" /></div>
              <div>
                <span className="work-tag">{p.tag}</span>
                <h2>{p.name}</h2>
                <p>{p.desc}</p>
                {p.href && <Btn href={p.href} icon="upright">Visit site</Btn>}
              </div>
            </article>
          ))}
        </div>
      </section>
      <Cta />
    </>
  );
}
