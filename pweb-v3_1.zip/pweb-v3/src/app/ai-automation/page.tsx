import { ServicePage } from '@/components/ServicePage';
import { pageMeta } from '@/lib/site';

export const metadata = pageMeta('/ai-automation', 'AI Automation & 24/7 Voice Phone Agents', 'Chat, WhatsApp and phone agents trained on your business. They answer questions, book appointments and hand over to you when needed.');

export default function Page() {
  return <ServicePage slug="ai-automation" />;
}
