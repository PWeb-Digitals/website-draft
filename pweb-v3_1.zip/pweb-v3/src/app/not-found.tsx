import { PageHero } from '@/components/PageHero';
import { Btn } from '@/components/ui';

export default function NotFound() {
  return (
    <PageHero label="404" title="This page doesn't exist." sub="It may have moved. Try the homepage, or tell us what you were looking for.">
      <Btn href="/" variant="dark" size="lg">Go to the homepage</Btn>
      <Btn href="/contact" size="lg">Contact us</Btn>
    </PageHero>
  );
}
