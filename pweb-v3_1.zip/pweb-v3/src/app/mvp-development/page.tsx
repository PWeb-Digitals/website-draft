import { ServicePage } from '@/components/ServicePage';
import { pageMeta } from '@/lib/site';

export const metadata = pageMeta('/mvp-development', 'MVP Development & Custom Web Apps', 'Turn your idea into a working product: clickable designs, then a web app with logins, payments and an admin area, live on your domain.');

export default function Page() {
  return <ServicePage slug="mvp-development" />;
}
