import Image from 'next/image';
import { notFound } from 'next/navigation';
import { getAllPublishedPosts, getPostBySlug } from '@/lib/blog';
import { pageMeta, SITE } from '@/lib/site';
import { PostBody } from '@/components/PostBody';
import { AuditBlock, Cta } from '@/components/Bottom';

export const revalidate = 3600;

export async function generateStaticParams() {
  return (await getAllPublishedPosts()).map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const p = await getPostBySlug(slug);
  if (!p) return { title: 'Article not found', robots: { index: false } };
  const meta = pageMeta(`/blog/${p.slug}`, p.seoTitle || p.title, p.seoDescription || p.excerpt, p.coverImage);
  return { ...meta, openGraph: { ...meta.openGraph, type: 'article' as const, publishedTime: p.publishedDate, modifiedTime: p.updatedDate } };
}

export default async function PostPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const p = await getPostBySlug(slug);
  if (!p) notFound();
  const ld = {
    '@context': 'https://schema.org',
    '@type': 'BlogPosting',
    headline: p.title,
    description: p.excerpt,
    image: p.coverImage.startsWith('http') ? p.coverImage : `${SITE.url}${p.coverImage}`,
    datePublished: p.publishedDate,
    dateModified: p.updatedDate,
    author: { '@type': 'Person', name: p.author.name },
    publisher: { '@type': 'Organization', name: SITE.name, logo: { '@type': 'ImageObject', url: `${SITE.url}/images/brand/pweb-logo-blue.png` } },
    mainEntityOfPage: `${SITE.url}/blog/${p.slug}`,
  };
  return (
    <>
      <article className="section" style={{ paddingTop: 64 }}>
        <header className="post-head container">
          <p className="crumbs"><a href="/blog">Blog</a> / {p.category}</p>
          <h1 className="t-h1">{p.title}</h1>
          <p className="t-body">{p.excerpt}</p>
          <p className="byline">
            <Image src={p.author.avatar} alt="" width={32} height={32} />
            {p.author.name} · {new Date(p.publishedDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })} · {p.readTime}
          </p>
        </header>
        <div className="post-cover container"><Image src={p.coverImage} alt={p.coverAlt} fill sizes="(min-width: 1080px) 1080px, 92vw" priority /></div>
        <div className="container" style={{ marginTop: 32 }}>{p.body && <PostBody body={p.body} />}</div>
      </article>
      <AuditBlock />
      <Cta />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} />
    </>
  );
}
