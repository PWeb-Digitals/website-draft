import Link from 'next/link';
import Image from 'next/image';
import { getAllPublishedPosts } from '@/lib/blog';
import { pageMeta } from '@/lib/site';
import { PageHero } from '@/components/PageHero';
import { AuditBlock } from '@/components/Bottom';
import { Btn } from '@/components/ui';

export const revalidate = 3600;
export const metadata = pageMeta('/blog', 'Blog: Websites, Automation & Growth', 'Practical articles on websites, CRM and follow-up, AI automation and getting more customers online, from the P-Web Digitals studio.');

export default async function BlogPage() {
  const posts = await getAllPublishedPosts();
  return (
    <>
      <PageHero label="Blog" title="Notes on websites, automation and growth." sub="Practical articles on getting more customers from your website, and the systems behind it." />
      <section className="container section" style={{ paddingTop: 0 }}>
        {posts.length ? (
          <div className="post-grid">
            {posts.map((p) => (
              <Link key={p.id} href={`/blog/${p.slug}`} className="post-card" data-reveal>
                <div className="pc-img"><Image src={p.coverImage} alt={p.coverAlt} fill sizes="(min-width: 860px) 340px, 92vw" /></div>
                <div className="pc-body">
                  <p className="pc-meta">{p.category} · {p.readTime}</p>
                  <h2>{p.title}</h2>
                  <p>{p.excerpt}</p>
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="empty-card" data-reveal>
            <h2 className="t-h3" style={{ fontWeight: 600 }}>New articles are on the way.</h2>
            <p>Join the newsletter at the bottom of this page to get them first.</p>
            <Btn href="/audit">Get a free website audit meanwhile</Btn>
          </div>
        )}
      </section>
      <AuditBlock />
    </>
  );
}
