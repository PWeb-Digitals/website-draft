import { LegalPage } from '@/components/LegalPage';
import { pageMeta } from '@/lib/site';

export const metadata = pageMeta('/disclaimer', 'Legal Disclaimer & Business Disclosures', 'Important information about the content on pwebdigitals.com and the limits of what our services and results can promise.');

export default function Page() {
  return <LegalPage slug="disclaimer" />;
}
