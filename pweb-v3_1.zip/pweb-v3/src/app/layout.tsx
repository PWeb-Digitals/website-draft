import type { Metadata, Viewport } from 'next';
import { Geist } from 'next/font/google';
import './globals.css';
import './sections.css';
import './sections2.css';
import './pages.css';
import { Header } from '@/components/Header';
import { Footer, Cookie } from '@/components/Bottom';
import { AuditPopup } from '@/components/AuditPopup';
import { Motion } from '@/components/Reveal';
import { AnalyticsScripts } from '@/components/AnalyticsScripts';
import { SITE } from '@/lib/site';

const geist = Geist({ subsets: ['latin'], variable: '--font-geist', display: 'swap', weight: ['400', '500', '600', '700'] });

const TITLE = 'Web Design & AI Automation Studio | P-Web Digitals';
const DESCRIPTION = 'Custom websites, CRM systems and AI voice agents for growing businesses worldwide. Built and managed by one founder you can talk to directly.';

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  title: { default: TITLE, template: '%s | P-Web Digitals' },
  description: DESCRIPTION,
  authors: [{ name: SITE.founder }],
  creator: SITE.founder,
  alternates: { canonical: SITE.url },
  openGraph: { type: 'website', locale: 'en_US', url: SITE.url, siteName: SITE.name, title: TITLE, description: DESCRIPTION, images: [{ url: '/images/og.jpg', width: 1200, height: 630, alt: 'P-Web Digitals, web design and AI automation studio' }] },
  twitter: { card: 'summary_large_image', title: TITLE, description: DESCRIPTION, images: ['/images/og.jpg'], creator: '@pweb_digitals' },
  robots: { index: true, follow: true, googleBot: { index: true, follow: true, 'max-video-preview': -1, 'max-image-preview': 'large', 'max-snippet': -1 } },
};
export const viewport: Viewport = { themeColor: '#f1f1f1', width: 'device-width', initialScale: 1 };

const ORG_LD = {
  '@context': 'https://schema.org',
  '@type': 'ProfessionalService',
  name: SITE.name,
  url: SITE.url,
  logo: `${SITE.url}/images/brand/pweb-logo-blue.png`,
  image: `${SITE.url}/images/og.jpg`,
  email: SITE.email,
  telephone: '+2348075709405',
  founder: { '@type': 'Person', name: SITE.founder },
  address: { '@type': 'PostalAddress', addressLocality: 'Akure', addressRegion: 'Ondo', addressCountry: 'NG' },
  areaServed: 'Worldwide',
  sameAs: ['https://www.instagram.com/pweb_digitals', 'https://x.com/pweb_digitals', 'https://www.linkedin.com/in/azubuike-peace-0b56b8435/', 'https://t.me/pwebdigitals'],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={geist.variable}>
      <body>
        <a href="#main" className="skip">Skip to content</a>
        <Motion />
        <Header />
        <main id="main">{children}</main>
        <Footer />
        <Cookie />
        <AuditPopup />
        <AnalyticsScripts />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ORG_LD) }} />
      </body>
    </html>
  );
}
