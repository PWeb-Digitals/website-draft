import { LegalPage } from '@/components/LegalPage';
import { pageMeta } from '@/lib/site';

export const metadata = pageMeta('/privacy', 'Privacy Policy & Client Data Protection', 'How P-Web Digitals collects, uses and protects the information you share through this website, our forms and client projects.');

export default function Page() {
  return <LegalPage slug="privacy" />;
}
