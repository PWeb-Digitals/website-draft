import { LegalPage } from '@/components/LegalPage';
import { pageMeta } from '@/lib/site';

export const metadata = pageMeta('/terms', 'Terms of Service & Engagement Conditions', 'The terms that apply when you use pwebdigitals.com or work with P-Web Digitals on a website, automation or software project.');

export default function Page() {
  return <LegalPage slug="terms" />;
}
