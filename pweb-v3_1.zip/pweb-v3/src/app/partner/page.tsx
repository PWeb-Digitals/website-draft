import { pageMeta } from '@/lib/site';
import { PageHero, SecIntro } from '@/components/PageHero';
import { FeatureGrid } from '@/components/FeatureGrid';
import { Cta } from '@/components/Bottom';
import { Btn } from '@/components/ui';

export const metadata = pageMeta('/partner', 'Partner With P-Web Digitals', 'For agencies, founders and growing businesses that need dependable monthly capacity for websites, CRM systems, AI automations and video.');

const ITEMS = [
  { t: 'Agencies', d: 'Extra hands for websites, CRM builds and automations, delivered under your brand.', icon: 'Briefcase' },
  { t: 'Founders', d: 'A build partner for your product or internal systems, from first version onwards.', icon: 'Rocket' },
  { t: 'Growing businesses', d: 'A monthly arrangement for updates, new pages, automations and video.', icon: 'Users' },
  { t: 'Clear terms', d: 'Scope, timelines and price agreed in writing before work starts.', icon: 'Handshake' },
];

export default function PartnerPage() {
  return (
    <>
      <PageHero label="Partner" title="Need a dependable build partner?" sub="For agencies, founders and growing businesses that need monthly capacity for websites, CRM systems, AI automations and video.">
        <Btn href="/book" variant="dark" size="lg">Start a conversation</Btn>
      </PageHero>
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container"><SecIntro center label="Who it's for" title="Ways we work together." /></div>
        <FeatureGrid items={ITEMS} />
      </section>
      <Cta title={<>Let&apos;s see if we&apos;re<br />a good fit.</>} body="Book a call and tell us what you need help with each month." cta="Book a call" />
    </>
  );
}
