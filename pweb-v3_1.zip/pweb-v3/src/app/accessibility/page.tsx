import { LegalPage } from '@/components/LegalPage';
import { pageMeta } from '@/lib/site';

export const metadata = pageMeta('/accessibility', 'Web Accessibility & Standards Policy', 'Our commitment to accessible websites: WCAG 2.1 AA as the target, and how to tell us if something on this site is hard to use.');

export default function Page() {
  return <LegalPage slug="accessibility" />;
}
