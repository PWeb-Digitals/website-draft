import { pageMeta } from '@/lib/site';
import { PageHero, SecIntro } from '@/components/PageHero';
import { FeatureGrid } from '@/components/FeatureGrid';
import { Cta, AuditBlock } from '@/components/Bottom';
import { Btn } from '@/components/ui';

export const metadata = pageMeta('/grow', 'Growth Systems: Websites, Funnels & Follow-Up', 'A website, landing pages, CRM pipeline and automatic follow-up working together, so more of the people who find you become paying customers.');

const ITEMS = [
  { t: 'A website that sells', d: 'Phone-first pages with one clear next step: book, buy, call or message.', icon: 'Globe' },
  { t: 'Landing pages and funnels', d: 'One offer, one action, built for the ads or posts sending traffic to it.', icon: 'LayoutTemplate' },
  { t: 'Instant follow-up', d: 'Every new lead gets a text or email within seconds, plus reminders.', icon: 'Zap' },
  { t: 'One pipeline', d: 'See who is new, who replied, who booked and who paid.', icon: 'KanbanSquare' },
  { t: 'Booking and payments', d: 'Appointments and deposits taken without the back-and-forth.', icon: 'CalendarCheck' },
  { t: 'Found on Google', d: 'Technical SEO and Google Business Profile so the right people find you.', icon: 'Search' },
];

export default function GrowPage() {
  return (
    <>
      <PageHero label="Grow" title="Get more customers from the people who already find you." sub="Your website, funnels, CRM and follow-up working as one system, so fewer enquiries slip away.">
        <Btn href="/book" variant="dark" size="lg">Book a free call</Btn>
        <Btn href="/lead-generation" size="lg">Funnels & lead generation</Btn>
      </PageHero>
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container"><SecIntro center label="The system" title="Six parts, connected." /></div>
        <FeatureGrid items={ITEMS} />
      </section>
      <AuditBlock />
      <Cta />
    </>
  );
}
