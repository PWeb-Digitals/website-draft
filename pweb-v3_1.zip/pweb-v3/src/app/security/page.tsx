import { LegalPage } from '@/components/LegalPage';
import { pageMeta } from '@/lib/site';

export const metadata = pageMeta('/security', 'Data Security & Infrastructure Standards', 'How P-Web Digitals keeps client logins, API keys and project data safe while we build and after handover.');

export default function Page() {
  return <LegalPage slug="security" />;
}
