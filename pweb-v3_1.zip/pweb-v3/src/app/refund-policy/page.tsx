import { LegalPage } from '@/components/LegalPage';
import { pageMeta } from '@/lib/site';

export const metadata = pageMeta('/refund-policy', 'Refund Terms & Project Milestone Policy', 'How payments, deposits, milestones and refunds work for website, automation and software projects with P-Web Digitals.');

export default function Page() {
  return <LegalPage slug="refund-policy" />;
}
