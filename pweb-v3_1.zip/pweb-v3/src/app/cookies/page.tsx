import { LegalPage } from '@/components/LegalPage';
import { pageMeta } from '@/lib/site';

export const metadata = pageMeta('/cookies', 'Cookie Policy & Privacy Storage Notice', 'Which cookies and browser storage pwebdigitals.com uses, why we use them, and how you can control them.');

export default function Page() {
  return <LegalPage slug="cookies" />;
}
