import { pageMeta, SITE } from '@/lib/site';
import { PageHero } from '@/components/PageHero';
import { CalEmbed } from '@/components/CalEmbed';

export const metadata = pageMeta('/book', 'Book a Free Discovery Call', 'Book a free 30-minute call with founder Peace Azubuike. We look at where customers slip away today and what to fix first.');

export default function BookPage() {
  return (
    <>
      <PageHero label="Book a call" title="Pick a time that works for you." sub="A free 30-minute call with Peace. We look at where customers slip away today and what to fix first. No pressure to buy." />
      <section className="container section" style={{ paddingTop: 0 }}>
        <div className="cal-card"><CalEmbed calLink={SITE.calLink} /></div>
        <p className="t-body center" style={{ marginTop: 20 }}>Prefer WhatsApp? <a className="ul" href={SITE.whatsapp} target="_blank" rel="noopener">Message us</a>.</p>
      </section>
    </>
  );
}
