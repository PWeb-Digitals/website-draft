import { pageMeta } from '@/lib/site';
import { PageHero } from '@/components/PageHero';
import { Cta } from '@/components/Bottom';
import { Btn, Check } from '@/components/ui';

export const metadata = pageMeta('/ventures', 'Ventures: Tools We Are Building', 'Products and automation blueprints in development at the P-Web Digitals studio, built from the problems we solve for clients every week.');

/** From the previous site, reworded. Both are works in progress and say so. */
const VENTURES = [
  {
    name: 'SyncFlow',
    status: 'In development',
    desc: 'Connects online payments to your CRM, so a Paystack or Stripe payment updates the customer record, sends the receipt and starts onboarding by itself.',
    points: ['Payment confirmations trigger the next step', 'Customer tagged in your CRM', 'Receipts and welcome messages sent automatically'],
  },
  {
    name: 'Client OS',
    status: 'Prototype',
    desc: 'A ready-made setup for agencies and studios that links project intake, client onboarding and a pipeline, so you stop rebuilding the same forms and folders.',
    points: ['Intake questionnaire and qualification', 'Onboarding steps that run on their own', 'Pipeline stages for every client'],
  },
];

export default function VenturesPage() {
  return (
    <>
      <PageHero label="Ventures" title="Tools we're building from client work." sub="Products in development at the studio. Want early access? Tell us what you'd use it for." />
      <section className="container section" style={{ paddingTop: 0 }}>
        <div className="grid-2">
          {VENTURES.map((v, i) => (
            <article key={v.name} className={`tile-card${i === 0 ? ' dark' : ''}`} data-reveal>
              <span className="work-tag" style={{ alignSelf: 'flex-start' }}>{v.status}</span>
              <div>
                <h2>{v.name}</h2>
                <p>{v.desc}</p>
                <ul className="tpl-features" style={{ gridTemplateColumns: '1fr' }}>{v.points.map((x) => <li key={x}><Check />{x}</li>)}</ul>
                <div style={{ marginTop: 24 }}><Btn href="/contact" variant={i === 0 ? 'white' : 'dark'}>Ask for early access</Btn></div>
              </div>
            </article>
          ))}
        </div>
      </section>
      <Cta />
    </>
  );
}
