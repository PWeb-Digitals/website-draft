import type { MetadataRoute } from 'next';
import { getAllPublishedPosts } from '@/lib/blog';
import { getTemplates } from '@/lib/content';
import { CASE_STUDIES } from '@/lib/caseStudies';
import { SERVICES } from '@/lib/services';
import { SITE } from '@/lib/site';

export const revalidate = 3600;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const now = new Date();
  const u = (path: string, priority: number, changeFrequency: MetadataRoute.Sitemap[number]['changeFrequency'], lastModified: Date = now) =>
    ({ url: `${SITE.url}${path}`, lastModified, changeFrequency, priority });

  const [posts, templates] = await Promise.all([getAllPublishedPosts().catch(() => []), getTemplates().catch(() => [])]);

  return [
    u('', 1, 'weekly'),
    u('/services', 0.9, 'monthly'),
    ...SERVICES.map((s) => u(s.href, 0.9, 'monthly')),
    ...['/work', '/about', '/pricing', '/contact', '/book', '/blog', '/templates', '/audit'].map((p) => u(p, 0.8, 'weekly')),
    ...['/grow', '/build', '/partner', '/ventures'].map((p) => u(p, 0.6, 'monthly')),
    ...CASE_STUDIES.map((c) => u(`/work/${c.slug}`, 0.6, 'monthly')),
    ...templates.map((t) => u(`/templates/${t.slug}`, 0.7, 'monthly')),
    ...posts.map((p) => u(`/blog/${p.slug}`, 0.7, 'monthly', p.updatedDate ? new Date(p.updatedDate) : now)),
    ...['/privacy', '/terms', '/refund-policy', '/security', '/cookies', '/disclaimer', '/accessibility'].map((p) => u(p, 0.3, 'yearly')),
  ];
}
