import { ServicePage } from '@/components/ServicePage';
import { pageMeta } from '@/lib/site';

export const metadata = pageMeta('/seo', 'SEO & Local Search for Growing Businesses', 'Technical fixes, Google Business Profile and content that helps the right people find your business on Google.');

export default function Page() {
  return <ServicePage slug="seo" />;
}
