import Link from 'next/link';
import { SERVICES, SERVICE_DATA } from '@/lib/services';
import { pageMeta } from '@/lib/site';
import { PageHero } from '@/components/PageHero';
import { AuditBlock, Cta } from '@/components/Bottom';
import { Btn, ArrowUpRight } from '@/components/ui';

export const metadata = pageMeta('/services', 'Web Design, CRM & AI Automation Services', 'Web design, funnels, CRM and follow-up, AI chat and voice agents, SEO, MVPs and AI video. Start with one, or connect them into one system.');

export default function ServicesPage() {
  return (
    <>
      <PageHero label="Services" title="Everything your business needs to win customers online." sub="Start with one service, or let us connect them into one system that answers, books, gets you paid and follows up.">
        <Btn href="/book" variant="dark" size="lg">Book a free call</Btn>
      </PageHero>
      <section className="container section" style={{ paddingTop: 0 }}>
        <div className="grid-2">
          {SERVICES.map((s, i) => (
            <Link key={s.href} href={s.href} className={`tile-card${i === 0 ? ' dark' : ''}`} data-reveal style={{ transitionDelay: `${(i % 2) * 70}ms` }}>
              <span className="tc-ico"><s.Icon size={18} strokeWidth={1.5} /></span>
              <span className="tc-go"><ArrowUpRight /></span>
              <div>
                <h2>{s.title}</h2>
                <p>{SERVICE_DATA[s.slug]?.sub || s.desc}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>
      <AuditBlock />
      <Cta />
    </>
  );
}
