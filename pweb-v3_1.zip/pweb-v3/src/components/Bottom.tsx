'use client';

import Link from 'next/link';
import Image from 'next/image';
import { useEffect, useRef, useState } from 'react';
import { usePathname } from 'next/navigation';
import { SiX, SiInstagram, SiTelegram, SiWhatsapp } from 'react-icons/si';
import { Search } from 'lucide-react';
import { FaLinkedin } from 'react-icons/fa6';
import { SERVICES } from '@/lib/services';
import { SITE, SOCIALS } from '@/lib/site';
import { AuditForm } from './AuditForm';
import { Btn, LogoMark, Marker, Plus, Wordmark, ArrowUpRight } from './ui';

/* ---------- Founder (dark) ---------- */
export function Founder() {
  return (
    <section className="founders">
      <div className="fd-inner fd-two container">
        <figure className="fd-person" data-reveal>
          <div className="portrait"><Image src="/images/peace-azubuike.jpg" alt="Peace Azubuike" fill sizes="(min-width: 860px) 320px, 70vw" /></div>
          <figcaption><span className="g">Peace</span> Azubuike<small>Founder, P-Web Digitals</small></figcaption>
        </figure>
        <div className="fd-copy" data-reveal>
          <LogoMark size={30} white />
          <h2 className="t-h2">One founder you can<br />talk to directly.</h2>
          <p>P-Web Digitals is my studio in Akure, Nigeria. I started it because most business websites look fine and bring in nothing.</p>
          <p>Every project goes through me, from the first call to the handover, for clients in Nigeria and around the world.</p>
          <Btn href="/about" variant="white">More about me</Btn>
        </div>
      </div>
    </section>
  );
}

/* ---------- Free audit (sits where the reference has its pledge block) ---------- */
export function AuditBlock() {
  return (
    <section className="pledge container" id="audit">
      <div className="pl-copy" data-reveal>
        <p className="pl-logo"><span className="pl-ico" aria-hidden="true"><Search size={22} strokeWidth={2} /></span>Free website audit</p>
        <p className="t-body">Send us your link. We check speed, how it works on a phone, the Google basics and what happens after someone gets in touch. Then we email you what to fix first.</p>
        <Btn href="/book">Or book a call</Btn>
      </div>
      <div className="pl-phone pl-form" data-reveal>
        <Marker pos="tl" /><Marker pos="tr" /><Marker pos="bl" /><Marker pos="br" />
        <div className="pl-screen">
          <p className="pl-chip">No call needed</p>
          <h3>Where is your website losing customers?</h3>
          <AuditForm compact />
        </div>
      </div>
    </section>
  );
}

/* ---------- FAQ ---------- */
export type Qa = { q: string; a: string };

export const HOME_FAQS: Qa[] = [
  { q: 'How much does a website cost?', a: 'It depends on the number of pages and what it needs to do. You get a fixed price in writing after a short call, before any work starts.' },
  { q: 'How long does it take?', a: 'Most websites take 2 to 4 weeks. Automations and AI agents usually take 1 to 3 weeks, depending on how many tools we connect.' },
  { q: 'Do you work with businesses outside Nigeria?', a: 'Yes. We work with clients in Nigeria and abroad, and take payment by Paystack, Stripe or PayPal.' },
  { q: 'Will I own the website?', a: 'Yes. The domain, files and logins are in your name, and you get short video guides on how to run it.' },
  { q: 'Can you improve my existing website instead?', a: 'Yes. Start with the free audit and we will tell you what to fix first.' },
];

function FaqItem({ q, a }: Qa) {
  const [open, setOpen] = useState(false);
  const body = useRef<HTMLDivElement>(null);
  return (
    <div className={`faq-item${open ? ' open' : ''}`}>
      <button type="button" className="faq-q" aria-expanded={open} onClick={() => setOpen(!open)}>
        <span>{q}</span>
        <span className="faq-ico"><Plus /></span>
      </button>
      <div className="faq-a" style={{ height: open ? body.current?.scrollHeight : 0 }}>
        <div ref={body}><p>{a}</p></div>
      </div>
    </div>
  );
}

export function Faq({ items = HOME_FAQS, title = 'FAQ' }: { items?: Qa[]; title?: string }) {
  const ld = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: items.map((f) => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: f.a } })),
  };
  return (
    <section className="faq container">
      <h2 className="t-h2 center" data-reveal>{title}</h2>
      <div className="faq-card" data-reveal>
        {items.map((f) => <FaqItem key={f.q} {...f} />)}
      </div>
      <p className="faq-more">More questions? <a href={SITE.whatsapp} target="_blank" rel="noopener">Message us on WhatsApp</a>.</p>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} />
    </section>
  );
}

/* ---------- Closing CTA over the drifting-sites video ---------- */
export function Cta({
  title = <>Let&apos;s build the system that<br />brings you customers.</>,
  body = 'Book a free 30-minute call. We’ll look at where customers slip away today and what to fix first.',
  cta = 'Book a free call',
  href = '/book',
}: { title?: React.ReactNode; body?: string; cta?: string; href?: string }) {
  const v = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    const el = v.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => (e.isIntersecting ? el.play().catch(() => {}) : el.pause()), { threshold: 0.1 });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <section className="cta-sec">
      <video ref={v} className="cta-bg" src="/videos/cta.mp4" muted loop playsInline preload="none" aria-hidden="true" />
      <div className="cta-fade" aria-hidden="true" />
      <div className="cta-card" data-reveal>
        <LogoMark size={30} white />
        <h2 className="t-h2">{title}</h2>
        <p>{body}</p>
        <Btn href={href} variant="white">{cta}</Btn>
      </div>
    </section>
  );
}

/* ---------- Footer ---------- */
const COLS = [
  { h: '/Services', l: SERVICES.map((s) => ({ t: s.title, h: s.href })) },
  { h: '/Studio', l: [{ t: 'Work', h: '/work' }, { t: 'Templates', h: '/templates' }, { t: 'Pricing', h: '/pricing' }, { t: 'Blog', h: '/blog' }, { t: 'Build', h: '/build' }, { t: 'Grow', h: '/grow' }] },
  { h: '/Company', l: [{ t: 'About', h: '/about' }, { t: 'Contact', h: '/contact' }, { t: 'Book a call', h: '/book' }, { t: 'Partner', h: '/partner' }, { t: 'Ventures', h: '/ventures' }] },
  { h: '/Legal', l: [{ t: 'Privacy Policy', h: '/privacy' }, { t: 'Terms', h: '/terms' }, { t: 'Refund Policy', h: '/refund-policy' }, { t: 'Cookies', h: '/cookies' }, { t: 'Security', h: '/security' }, { t: 'Accessibility', h: '/accessibility' }, { t: 'Disclaimer', h: '/disclaimer' }] },
];

const SOCIAL_ICONS = { instagram: SiInstagram, x: SiX, linkedin: FaLinkedin, telegram: SiTelegram, whatsapp: SiWhatsapp } as const;

export function Footer() {
  const page = usePathname();
  const [state, setState] = useState<'idle' | 'sending' | 'done' | 'error'>('idle');
  async function subscribe(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setState('sending');
    try {
      const res = await fetch('/api/contact', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: fd.get('name'), email: fd.get('email'), company: fd.get('company'), pathway: 'newsletter', page }) });
      setState(res.ok ? 'done' : 'error');
    } catch { setState('error'); }
  }
  return (
    <footer className="site-footer">
      <div className="ft-main container">
        <div className="ft-brand">
          <Link href="/" aria-label="P-Web Digitals home"><Wordmark /></Link>
          <p>Websites, CRM systems and AI automation for growing businesses. Built in {SITE.location}, for clients worldwide.</p>
          <p className="ft-contact"><a href={`mailto:${SITE.email}`}>{SITE.email}</a><br /><a href={SITE.whatsapp} target="_blank" rel="noopener">{SITE.whatsappLabel}</a></p>
        </div>
        <nav className="ft-cols" aria-label="Footer">
          {COLS.map((c) => (
            <div key={c.h}>
              <p className="ft-h">{c.h}</p>
              <ul>{c.l.map((x) => <li key={x.h}><Link href={x.h}>{x.t}</Link></li>)}</ul>
            </div>
          ))}
        </nav>
        <form className="newsletter" onSubmit={subscribe}>
          <h3>Join our newsletter.</h3>
          <p>Short, useful notes on websites, automation and getting more customers. No spam.</p>
          {state === 'done' ? <p className="nl-done">Thanks, you&apos;re on the list.</p> : (
            <>
              <label className="sr" htmlFor="nl-name">Your name</label>
              <input id="nl-name" name="name" placeholder="Your name" autoComplete="name" />
              <label className="sr" htmlFor="nl-email">Email</label>
              <input id="nl-email" name="email" type="email" placeholder="your.address@email.com" required autoComplete="email" />
              <input name="company" tabIndex={-1} autoComplete="off" className="hp" aria-hidden="true" />
              <button type="submit" disabled={state === 'sending'}>{state === 'sending' ? 'Joining…' : 'Count me in!'} <ArrowUpRight /></button>
              {state === 'error' && <p className="form-err" role="alert">That didn&apos;t work. Please try again.</p>}
            </>
          )}
        </form>
      </div>
      <div className="ft-bottom container">
        <div className="socials">
          {SOCIALS.map(({ label, href, key }) => {
            const I = SOCIAL_ICONS[key];
            return <a key={key} href={href} target="_blank" rel="noopener" aria-label={label}><I size={18} /></a>;
          })}
          <a href={`mailto:${SITE.email}`} aria-label="Email"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="currentColor" strokeWidth="1.4" aria-hidden="true"><rect x="2" y="4" width="14" height="10" rx="2" /><path d="M2.5 5l6.5 5 6.5-5" /></svg></a>
        </div>
        <p>© {new Date().getFullYear()} P-Web Digitals. All Rights Reserved.</p>
      </div>
    </footer>
  );
}

/* ---------- Cookie notice ---------- */
export function Cookie() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    try { if (!localStorage.getItem('cookie-ok')) setTimeout(() => setShow(true), 1200); } catch { /* storage blocked */ }
  }, []);
  if (!show) return null;
  const close = () => { try { localStorage.setItem('cookie-ok', '1'); } catch { /* ignore */ } setShow(false); };
  return (
    <section className="cookie" aria-label="Cookies">
      <p><strong>Cookies</strong>We use necessary cookies to run this site and analytics cookies to understand how it is used. You can read more in our <Link href="/cookies">Cookie Policy</Link> and <Link href="/privacy">Privacy Policy</Link>.</p>
      <div>
        <button type="button" className="ok" onClick={close}>OK</button>
      </div>
    </section>
  );
}
