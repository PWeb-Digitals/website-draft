import Link from 'next/link';
import { SERVICE_DATA, SERVICES } from '@/lib/services';
import { P, PlatformIcon } from '@/lib/platforms';
import { SITE } from '@/lib/site';
import { PageHero, SecIntro } from './PageHero';
import { FeatureGrid } from './FeatureGrid';
import { Faq, Cta, AuditBlock } from './Bottom';
import { Btn, Check, ArrowUpRight } from './ui';

/** Every service page uses this layout. Copy lives in src/lib/serviceData.ts. */
export function ServicePage({ slug }: { slug: string }) {
  const d = SERVICE_DATA[slug];
  const svc = SERVICES.find((s) => s.slug === slug)!;
  const related = d.related.map((r) => SERVICES.find((s) => s.slug === r)).filter(Boolean) as typeof SERVICES;
  const ld = {
    '@context': 'https://schema.org',
    '@type': 'Service',
    name: svc.title,
    description: d.sub,
    provider: { '@type': 'ProfessionalService', name: SITE.name, url: SITE.url },
    areaServed: 'Worldwide',
    url: `${SITE.url}${svc.href}`,
  };
  return (
    <>
      <PageHero crumbs={[{ href: '/services', t: 'Services' }, { href: svc.href, t: svc.title }]} title={d.title} sub={d.sub}>
        <Btn href="/book" variant="dark" size="lg">Book a free call</Btn>
        <Btn href="#audit" size="lg">Free website audit</Btn>
      </PageHero>

      <section className="container" aria-label="Tools we use for this">
        <p className="t-body center" style={{ marginBottom: 16 }}>Tools we build with and connect</p>
        <div className="tool-row">
          {d.platforms.map((k) => P[k] && (
            <span key={k} className="tool-chip">
              <PlatformIcon p={{ ...P[k], color: ['#ffffff', '#c0e6fd'].includes(P[k].color.toLowerCase()) ? '#0a0a0a' : P[k].color }} size={16} />
              {P[k].name}
            </span>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="container"><SecIntro center label="What you get" title="Built for how your customers buy." /></div>
        <FeatureGrid items={slug} />
      </section>

      <section className="section container">
        <div className="include-card" data-reveal>
          <div>
            <p className="t-label" style={{ color: 'var(--grey-2)' }}>Included</p>
            <h2 className="t-h2" style={{ marginTop: 12 }}>What&apos;s included.</h2>
            <p>Every project gets a fixed scope and price in writing before any work starts. You own everything at the end.</p>
            <div style={{ marginTop: 24 }}><Btn href="/pricing" variant="white">See pricing</Btn></div>
          </div>
          <ul>
            {d.includes.map((x) => <li key={x}><Check />{x}</li>)}
          </ul>
        </div>
      </section>

      <AuditBlock />

      <Faq items={d.faqs} title="Questions" />

      <section className="section container">
        <SecIntro label="Works well with" title="Related services." />
        <div className="grid-3">
          {related.map((r) => (
            <Link key={r.href} href={r.href} className="tile-card" data-reveal>
              <span className="tc-ico"><r.Icon size={18} strokeWidth={1.5} /></span>
              <span className="tc-go"><ArrowUpRight /></span>
              <div>
                <h3>{r.title}</h3>
                <p>{SERVICE_DATA[r.slug]?.sub || r.desc}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <Cta />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} />
    </>
  );
}
