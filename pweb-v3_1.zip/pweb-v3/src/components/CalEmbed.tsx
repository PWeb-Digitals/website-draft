'use client';

import { useEffect } from 'react';
import Cal, { getCalApi } from '@calcom/embed-react';

/** Cal.com booking calendar in the light theme. */
export function CalEmbed({ calLink = 'pweb-digitals/consultation', namespace = 'consultation' }: { calLink?: string; namespace?: string }) {
  useEffect(() => {
    (async () => {
      try {
        const cal = await getCalApi({ namespace });
        cal('ui', { theme: 'light', styles: { branding: { brandColor: '#0b0b0c' } }, hideEventTypeDetails: false, layout: 'month_view' });
      } catch (err) {
        console.error('Cal embed failed', err);
      }
    })();
  }, [namespace]);
  return (
    <div>
      <Cal namespace={namespace} calLink={calLink} style={{ width: '100%', minHeight: 680, overflow: 'auto' }} config={{ layout: 'month_view', theme: 'light' }} />
    </div>
  );
}
