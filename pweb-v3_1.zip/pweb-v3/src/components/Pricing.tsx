import Link from 'next/link';
import { ArrowUpRight, Check, Marker } from './ui';

/**
 * Prices copied from the live site (Oct 2026). Pricing isn't final yet (see AGENTS.md, "Still open"),
 * so confirm these before launch. Naira prices are agreed at the day's rate when the quote is accepted.
 */
const PLANS = [
  { name: 'Launch', desc: 'A landing page or small site to get you online properly.', from: false, amount: '100–500', per: 'one-off project', cta: 'Start a launch', note: 'Landing page or small site', items: ['1 to 3 custom pages', 'Phone-first and quick to load', 'Contact form to email and WhatsApp', 'Google basics set up', 'You own everything'], tone: 'grey' },
  { name: 'Growth', desc: 'A full website or funnel, connected to booking, payments and follow-up.', from: false, amount: '1,000', per: 'one-off project', cta: 'Start growth', note: 'Most popular', items: ['Everything in Launch', 'Full website or sales funnel', 'Booking and payment checkout', 'Instant lead alerts and follow-up', 'CRM pipeline set up', 'Support after launch'], tone: 'white' },
  { name: 'Ongoing', desc: 'Monthly improvements, AI agents and automations as you grow.', from: true, amount: '100', per: '/month', cta: 'Talk about it', note: 'Cancel anytime', badge: 'Monthly', items: ['Monthly updates and improvements', 'AI chat and voice agents', 'Automations as you grow', 'Direct WhatsApp line to Peace'], tone: 'black' },
];

export function Pricing({ heading = 'Clear prices, agreed before work starts.' }: { heading?: string }) {
  return (
    <section className="pricing container" id="pricing">
      <div className="pr-head" data-reveal>
        <div>
          <p className="t-label">Pricing &amp; Plans</p>
          <h2 className="t-h2">{heading}</h2>
        </div>
        <p className="pr-pill">Fixed price in writing · Pay in USD or NGN</p>
      </div>
      <div className="pr-frame">
        <Marker pos="tl" /><Marker pos="tr" /><Marker pos="bl" /><Marker pos="br" />
        {PLANS.map((p) => (
          <article key={p.name} className={`plan ${p.tone}`} data-reveal>
            <div className="plan-top">
              <h3>{p.name}<span className="red-dot">.</span></h3>
              {p.badge && <span className="badge">{p.badge}</span>}
            </div>
            <p className="plan-desc">{p.desc}</p>
            <p className="price">
              {p.from && <span className="from">From</span>}
              <span className="cur">$</span>
              <span className={`num${p.amount.length > 5 ? ' long' : ''}`}>{p.amount}</span>
              <span className="per">{p.per}</span>
            </p>
            <Link href="/book" className="plan-btn">{p.cta} <ArrowUpRight /></Link>
            <p className="plan-note">{p.note}</p>
            <hr />
            <ul>
              {p.items.map((it, k) => <li key={k}><Check />{it}</li>)}
            </ul>
          </article>
        ))}
      </div>
      <p className="pr-fix" data-reveal>Just need a fix? Bug, layout and form fixes <strong>from $50</strong>, usually done in 1 to 2 days. <Link href="/contact" className="ul">Get a fix</Link></p>
    </section>
  );
}
