import Image from 'next/image';
import { SiInstagram } from 'react-icons/si';
import type { IgPost } from '@/lib/instagram';
import { Btn } from './ui';

/**
 * Sits where the reference has its testimonials. There are no client testimonials on the site yet,
 * so this shows how a project runs instead. When real reviews exist, they can go back here.
 */
const STEPS = [
  { n: '02', t: 'Fixed scope and price', d: 'You get the scope and a fixed price in writing before any work starts.' },
  { n: '03', t: 'We build with you', d: 'You see progress as it takes shape and give feedback along the way.' },
  { n: '04', t: 'You own everything', d: 'Domain, files and logins stay in your name, with short video guides at handover.' },
];

export function Approach() {
  return (
    <section className="testimonials container" id="process">
      <div className="sec-head center" data-reveal>
        <p className="t-label">How we work</p>
        <h2 className="t-h2">You talk to the person building it.</h2>
      </div>
      <article className="video-review" data-reveal>
        <div className="vr-copy">
          <p className="vr-step">Step 01 · We talk</p>
          <blockquote>A short call or WhatsApp chat about what you need and where customers are slipping away.</blockquote>
          <div className="vr-person">
            <strong>Peace Azubuike</strong>
            <span>Founder, P-Web Digitals</span>
          </div>
        </div>
        <div className="vr-media">
          <Image src="/images/peace-azubuike.jpg" alt="Peace Azubuike, founder of P-Web Digitals" fill sizes="(min-width: 860px) 540px, 92vw" className="vr-photo" />
        </div>
      </article>
      <div className="review-grid">
        {STEPS.map((s, i) => (
          <article key={s.n} className="review card" data-reveal style={{ transitionDelay: `${i * 80}ms` }}>
            <p className="step-n">Step {s.n}</p>
            <h3>{s.t}</h3>
            <p>{s.d}</p>
          </article>
        ))}
      </div>
      <div className="center-btn"><Btn href="/about">More about us</Btn></div>
    </section>
  );
}

/** Dark wall of Instagram posts scrolling in columns. Hidden when there's no Instagram token. */
export function InstaWall({ posts }: { posts: IgPost[] }) {
  if (posts.length < 6) return null;
  const per = Math.ceil(posts.length / 3);
  const cols = [posts.slice(0, per), posts.slice(per, per * 2), posts.slice(per * 2)];
  return (
    <section className="loved insta" aria-label="Latest posts on Instagram">
      <div className="loved-cols container">
        {cols.map((col, c) => (
          <div key={c} className={`loved-col${c === 1 ? ' down' : ''}`} style={{ animationDuration: `${38 + c * 9}s` }}>
            {[...col, ...col].map((p, i) => (
              <a key={`${p.id}-${i}`} href={p.permalink} target="_blank" rel="noopener" className="tweet ig" aria-hidden={i >= col.length} tabIndex={i >= col.length ? -1 : 0}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={p.image} alt={p.caption || 'Instagram post'} loading="lazy" />
                {p.caption && <p className="tw-text">{p.caption}</p>}
              </a>
            ))}
          </div>
        ))}
      </div>
      <h2 className="loved-title t-h1"><span className="red-dot">Follow</span> the work.</h2>
      <a className="insta-link" href="https://www.instagram.com/pweb_digitals" target="_blank" rel="noopener"><SiInstagram size={16} /> @pweb_digitals</a>
    </section>
  );
}
