'use client';

import { useEffect, useRef } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { P, PlatformIcon } from '@/lib/platforms';
import { Btn, Marker } from './ui';

const TOOLS = [P.whatsapp, P.paystack, P.cal, P.n8n, P.stripe, P.claude];

export function Hero() {
  const vid = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    const v = vid.current;
    if (!v) return;
    const io = new IntersectionObserver(([e]) => (e.isIntersecting ? v.play().catch(() => {}) : v.pause()), { threshold: 0.2 });
    io.observe(v);
    return () => io.disconnect();
  }, []);

  return (
    <>
      <section className="hero">
        <div className="hero-backdrop" aria-hidden="true" />
        <div className="hero-copy container">
          <div className="rating" data-reveal>
            <span className="faces">
              <Image src="/images/peace-azubuike.jpg" alt="" width={56} height={56} className="face" />
            </span>
            <span>Founder-led studio · Akure, Nigeria · clients worldwide</span>
          </div>
          <h1 className="t-display" data-reveal>Websites and AI systems that bring you customers<span className="red-dot">.</span></h1>
          <p className="t-body lede" data-reveal>We design your website and connect it to everything behind it: instant replies, booking, payments and follow-up. One system, built for your business.</p>
          <div className="cta" data-reveal>
            <Btn href="/book" variant="dark" size="lg">Book a free call</Btn>
            <p className="t-body-s note">Or <Link href="#audit" className="ul">get a free website audit</Link></p>
          </div>
        </div>

        <div className="hero-frame container" data-reveal>
          <Marker pos="tl" /><Marker pos="tr" /><Marker pos="bl" /><Marker pos="br" />
          <div className="hero-window">
            <video ref={vid} src="/videos/hero.mp4" poster="/videos/hero-poster.jpg" muted loop playsInline preload="metadata" aria-label="Demo: a request in chat becomes a new section on a live website" />
          </div>
        </div>
      </section>

      <section className="logos container">
        <p className="t-body line">Connected to the tools you already use. <a href="#integration">See how</a></p>
        <ul className="tools">
          {TOOLS.map((t) => (
            <li key={t.name} className="tile" title={t.name}>
              <PlatformIcon p={{ ...t, color: t.color.toLowerCase() === '#ffffff' ? '#0a0a0a' : t.color }} size={26} />
              <span className="sr">{t.name}</span>
            </li>
          ))}
          <li className="tile" title="And more"><span className="tile-letter">+</span><span className="sr">and more</span></li>
        </ul>
        <Marker pos="bl" /><Marker pos="br" />
      </section>
    </>
  );
}
