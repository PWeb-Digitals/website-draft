import { MessageCircle, PhoneCall, CalendarCheck, CreditCard, KanbanSquare, Star, type LucideIcon } from 'lucide-react';
import { ICONS, SERVICE_DATA } from '@/lib/services';
import { Marker } from './ui';

export type Feature = { t: string; d: string; Icon: LucideIcon };

export const SYSTEM: Feature[] = [
  { t: 'Every enquiry answered', d: 'New messages from your site, WhatsApp or Instagram get a helpful reply in seconds, day or night.', Icon: MessageCircle },
  { t: 'Missed calls picked up', d: 'A voice agent answers when you can’t, takes the details and books the appointment.', Icon: PhoneCall },
  { t: 'Straight into your calendar', d: 'Customers pick a time that works and it lands in the calendar you already use.', Icon: CalendarCheck },
  { t: 'Deposits without chasing', d: 'Payment links by Paystack, Stripe or PayPal, with receipts sent automatically.', Icon: CreditCard },
  { t: 'No lead forgotten', d: 'One pipeline shows who is new, who replied, who booked and who paid.', Icon: KanbanSquare },
  { t: 'Reviews on autopilot', d: 'Happy customers are asked for a Google review at the right moment.', Icon: Star },
];

type Item = { t: string; d: string; icon: string };

/**
 * Six-card grid in the reference style.
 * Pass "system" for the homepage set, a service slug for that service's features, or a list of { t, d, icon }.
 */
export function FeatureGrid({ items, framed = true }: { items: 'system' | string | Item[]; framed?: boolean }) {
  let list: Feature[];
  if (items === 'system') list = SYSTEM;
  else if (typeof items === 'string') list = (SERVICE_DATA[items]?.features || []).map((f) => ({ t: f.title, d: f.desc, Icon: ICONS[f.icon] || Star }));
  else list = items.map((f) => ({ t: f.t, d: f.d, Icon: ICONS[f.icon] || Star }));
  return (
    <section className={`features container${framed ? '' : ' plain'}`}>
      {framed && <><Marker pos="tl" /><Marker pos="tr" /><Marker pos="bl" /><Marker pos="br" /></>}
      <div className={`feature-grid${list.length === 4 ? ' four' : ''}`}>
        {list.map(({ t, d, Icon }, i) => (
          <article key={t} className="feature card" data-reveal style={{ transitionDelay: `${(i % 3) * 70}ms` }}>
            <span className="ico" aria-hidden="true"><Icon size={16} strokeWidth={1.5} /></span>
            <div>
              <h3>{t}</h3>
              <p>{d}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
