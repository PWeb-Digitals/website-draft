'use client';

import { useEffect, useRef, useState } from 'react';
import Image from 'next/image';
import type { Project } from '@/lib/content';
import { Btn } from './ui';

const TICKS = 61;

export function Showcase({ items: projects }: { items: Project[] }) {
  // repeat short lists so the carousel always has neighbours on both sides
  const ITEMS = projects.length >= 5 ? projects : [...projects, ...projects].slice(0, Math.max(5, projects.length));
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const dragX = useRef<number | null>(null);
  const n = ITEMS.length;

  useEffect(() => {
    if (paused) return;
    const t = setInterval(() => setI((v) => (v + 1) % n), 3600);
    return () => clearInterval(t);
  }, [paused, n]);

  const go = (d: number) => setI((v) => (v + d + n) % n);

  return (
    <section className="showcase" id="showcase">
      <div className="sec-head center container" data-reveal>
        <p className="t-label">Selected work</p>
        <h2 className="t-h2">Built by us. Live now.</h2>
      </div>
      <div
        className="sc-track"
        role="region"
        aria-roledescription="carousel"
        aria-label="Project showcase"
        tabIndex={0}
        onKeyDown={(e) => { if (e.key === 'ArrowRight') go(1); if (e.key === 'ArrowLeft') go(-1); }}
        onMouseEnter={() => setPaused(true)}
        onMouseLeave={() => setPaused(false)}
        onPointerDown={(e) => { dragX.current = e.clientX; }}
        onPointerUp={(e) => { if (dragX.current !== null) { const d = e.clientX - dragX.current; if (Math.abs(d) > 40) go(d < 0 ? 1 : -1); } dragX.current = null; }}
      >
        {ITEMS.map((item, k) => {
          let off = k - i;
          if (off > n / 2) off -= n;
          if (off < -n / 2) off += n;
          const abs = Math.abs(off);
          return (
            <button
              key={`${item.slug}-${k}`}
              type="button"
              className={`sc-item${off === 0 ? ' active' : ''}`}
              style={{
                transform: `translate(-50%, -50%) translateX(${off * 62}%) scale(${off === 0 ? 1 : 0.76})`,
                opacity: abs > 1 ? 0 : off === 0 ? 1 : 0.9,
                zIndex: 10 - abs,
                pointerEvents: abs > 1 ? 'none' : 'auto',
              }}
              onClick={() => setI(k)}
              aria-label={`Show ${item.name}`}
              aria-current={off === 0}
            >
              <Image src={item.img} alt={`${item.name} website`} fill sizes="(min-width: 900px) 560px, 80vw" className="sc-img" draggable={false} />
            </button>
          );
        })}
      </div>
      <div className="wave" aria-hidden="true">
        {Array.from({ length: TICKS }).map((_, k) => {
          const d = Math.abs(k - (TICKS - 1) / 2);
          const h = d === 0 ? 32 : Math.max(8, 22 - d * 1.6) + (k % 5 === 0 ? 6 : 0);
          return <i key={`${i}-${k}`} style={{ height: h, animationDelay: `${d * 12}ms` }} className={d === 0 ? 'mid' : ''} />;
        })}
      </div>
      <p className="sc-label" aria-live="polite">
        <span>[</span>{' '}
        {ITEMS[i].href ? <a href={ITEMS[i].href} target="_blank" rel="noopener">{ITEMS[i].name}</a> : ITEMS[i].name}
        {' '}<span>]</span>
      </p>
      <p className="sc-desc">{ITEMS[i].tag}</p>
      <div className="center-btn"><Btn href="/work">See all work</Btn></div>
    </section>
  );
}
