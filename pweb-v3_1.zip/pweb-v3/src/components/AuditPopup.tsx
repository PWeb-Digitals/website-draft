'use client';

import { useEffect, useState } from 'react';
import { usePathname } from 'next/navigation';
import { AuditForm } from './AuditForm';

const KEY = 'pweb-audit-popup';
const WEEK = 7 * 24 * 60 * 60 * 1000;
const SKIP = ['/book', '/contact', '/audit', '/templates/'];

/** Shows once per visitor per 7 days: after 25s, at 50% scroll, or on desktop exit intent. A small bottom sheet on phones. */
export function AuditPopup() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (SKIP.some((p) => pathname?.startsWith(p))) return;
    try {
      if (Date.now() - Number(localStorage.getItem(KEY) || 0) < WEEK) return;
    } catch { /* storage blocked: still allow once per page view */ }
    let shown = false;
    const show = () => {
      if (shown) return;
      shown = true;
      setOpen(true);
      try { localStorage.setItem(KEY, String(Date.now())); } catch { /* ignore */ }
      cleanup();
    };
    const t = window.setTimeout(show, 25000);
    const onScroll = () => {
      const h = document.documentElement;
      if ((h.scrollTop + window.innerHeight) / h.scrollHeight > 0.5) show();
    };
    const onLeave = (e: MouseEvent) => { if (e.clientY <= 0 && !e.relatedTarget) show(); };
    window.addEventListener('scroll', onScroll, { passive: true });
    document.addEventListener('mouseout', onLeave);
    function cleanup() {
      window.clearTimeout(t);
      window.removeEventListener('scroll', onScroll);
      document.removeEventListener('mouseout', onLeave);
    }
    return cleanup;
  }, [pathname]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  if (!open) return null;
  return (
    <div className="audit-pop" role="dialog" aria-modal="false" aria-labelledby="audit-pop-title">
      <button type="button" className="ap-close" aria-label="Close" onClick={() => setOpen(false)}>
        <svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true"><path d="M2 2l10 10M12 2L2 12" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" /></svg>
      </button>
      <p className="t-label">Free · No call needed</p>
      <h2 id="audit-pop-title">Is your website losing you customers?</h2>
      <p className="ap-sub">Send your link. We&apos;ll check it and email you what to fix first.</p>
      <AuditForm compact />
    </div>
  );
}
