'use client';

import Link from 'next/link';
import { useId, useState } from 'react';
import { usePathname } from 'next/navigation';
import { SERVICES } from '@/lib/services';
import { ArrowUpRight, Check } from './ui';

type Status = 'idle' | 'sending' | 'done' | 'error';

/**
 * Contact form, also used as the template brief. With `template` set, it sends a template brief and,
 * when a Paystack payment page exists, takes the visitor there to pay the deposit.
 */
export function ContactForm({ template, paymentUrl }: { template?: string; paymentUrl?: string }) {
  const id = useId();
  const page = usePathname();
  const [status, setStatus] = useState<Status>('idle');

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setStatus('sending');
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: fd.get('name'), email: fd.get('email'), phone: fd.get('phone') || undefined,
          business: fd.get('business') || undefined, website: fd.get('website') || undefined,
          message: [fd.get('service') ? `Interested in: ${fd.get('service')}` : '', fd.get('message') || ''].filter(Boolean).join('\n\n'),
          budget: fd.get('budget') || undefined, company: fd.get('company'),
          pathway: template ? 'template-brief' : 'contact', template, page,
        }),
      });
      if (!res.ok) throw new Error(String(res.status));
      setStatus('done');
      if (template && paymentUrl) setTimeout(() => { window.location.href = paymentUrl; }, 1600);
    } catch {
      setStatus('error');
    }
  }

  if (status === 'done') {
    return (
      <div className="form-done" role="status">
        <span className="done-ico"><Check size={18} /></span>
        {template && paymentUrl ? (
          <>
            <p className="fd-title">Brief received. Taking you to payment…</p>
            <p className="fd-sub">If nothing happens, use the button below to pay the deposit by Paystack.</p>
            <a href={paymentUrl} className="form-btn">Pay the deposit <ArrowUpRight /></a>
          </>
        ) : (
          <>
            <p className="fd-title">Thanks, we&apos;ve got your message.</p>
            <p className="fd-sub">Peace will get back to you within one working day.</p>
            <Link href="/book" className="form-btn">Pick a call time now <ArrowUpRight /></Link>
          </>
        )}
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="pw-form">
      <div className="row">
        <label className="sr" htmlFor={`${id}-n`}>Your name</label>
        <input id={`${id}-n`} name="name" required placeholder="Your name" autoComplete="name" />
        <label className="sr" htmlFor={`${id}-e`}>Email</label>
        <input id={`${id}-e`} name="email" type="email" required placeholder="Email" autoComplete="email" />
      </div>
      <div className="row">
        <label className="sr" htmlFor={`${id}-p`}>WhatsApp or phone</label>
        <input id={`${id}-p`} name="phone" type="tel" placeholder="WhatsApp or phone" autoComplete="tel" required={Boolean(template)} />
        <label className="sr" htmlFor={`${id}-b`}>Business name</label>
        <input id={`${id}-b`} name="business" placeholder="Business name" autoComplete="organization" required={Boolean(template)} />
      </div>
      {!template && (
        <>
          <label className="sr" htmlFor={`${id}-s`}>What do you need?</label>
          <select id={`${id}-s`} name="service" defaultValue="">
            <option value="" disabled>What do you need?</option>
            {SERVICES.map((s) => <option key={s.href} value={s.title}>{s.title}</option>)}
            <option value="Not sure yet">Not sure yet</option>
          </select>
        </>
      )}
      <label className="sr" htmlFor={`${id}-w`}>Current website (optional)</label>
      <input id={`${id}-w`} name="website" type="url" placeholder="Current website (optional)" inputMode="url" />
      <label className="sr" htmlFor={`${id}-m`}>{template ? 'Tell us about your business' : 'Message'}</label>
      <textarea id={`${id}-m`} name="message" required placeholder={template ? 'Tell us about your business: what you sell, where you are, and anything the site must do.' : 'Tell us what you need and where customers are slipping away.'} />
      <input name="company" tabIndex={-1} autoComplete="off" className="hp" aria-hidden="true" />
      <button type="submit" className="form-btn" disabled={status === 'sending'}>
        {status === 'sending' ? 'Sending…' : template ? (paymentUrl ? 'Send brief and pay deposit' : 'Send my brief') : 'Send message'} <ArrowUpRight />
      </button>
      {status === 'error' && <p role="alert" className="form-err">Something went wrong. Please try again, or message us on WhatsApp.</p>}
    </form>
  );
}
