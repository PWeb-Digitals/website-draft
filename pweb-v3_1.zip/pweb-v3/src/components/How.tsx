'use client';

import { useEffect, useRef } from 'react';
import Image from 'next/image';
import { Btn } from './ui';

const PANELS = [
  { tag: 'WEB DESIGN', href: '/web-design', icon: 'M2 3h12v10H2zM2 6h12', title: 'A website that turns visitors into customers.', body: 'Designed on a phone screen first, quick to load and clear to read, with booking and payments built in.', cta: 'Explore web design', media: 'site' },
  { tag: 'AI AUTOMATION', href: '/ai-automation', icon: 'M8 1l1.6 4.4L14 7l-4.4 1.6L8 13l-1.6-4.4L2 7l4.4-1.6z', title: 'Every enquiry answered in seconds.', body: 'Chat, WhatsApp and phone agents trained on your business. They answer, book and hand over to you when needed.', cta: 'Explore AI automation', media: 'chat' },
  { tag: 'CRM & FOLLOW-UP', href: '/crm-automation', icon: 'M2 3h3v10H2zM6.5 3h3v7h-3zM11 3h3v5h-3z', title: 'Every lead tracked, booked, paid and followed up.', body: 'One pipeline for every enquiry, with reminders, payment links and review requests that run on their own.', cta: 'Explore CRM & follow-up', media: 'pipeline' },
];

function Media({ kind }: { kind: string }) {
  if (kind === 'site') {
    return <Image src="/images/work/sidney-sanni.webp" alt="Sidney Sanni website, designed and built by P-Web Digitals" fill sizes="(min-width: 900px) 520px, 92vw" className="media-img" />;
  }
  if (kind === 'chat') {
    return (
      <div className="mock-chat" aria-hidden="true">
        <p className="mc-head"><span className="mc-dot" />WhatsApp · replies in seconds</p>
        <p className="bubble me">Hi, how much is a 2-tier cake for Saturday?</p>
        <p className="bubble">From ₦[price]. Saturday is open. Would you like pickup or delivery?</p>
        <p className="bubble me">Delivery please</p>
        <p className="bubble">Done. Here is your order and a link to pay the deposit.</p>
        <p className="mc-link">Pay deposit · Paystack</p>
      </div>
    );
  }
  return (
    <div className="mock-pipe" aria-hidden="true">
      {[['New', ['Ada · Website', 'Tunde · Booking']], ['Replied', ['Grace · Quote']], ['Booked', ['Mike · Sat 10am', 'Ife · Mon 2pm']], ['Paid', ['Sola · Deposit']]].map(([col, cards]) => (
        <div key={col as string} className="mp-col">
          <p>{col as string}</p>
          {(cards as string[]).map((c) => <span key={c} className="mp-card">{c}</span>)}
        </div>
      ))}
    </div>
  );
}

/** Panels pin one after another and stack; earlier panels shrink slightly as the next one covers them. */
export function How() {
  const refs = useRef<(HTMLElement | null)[]>([]);

  useEffect(() => {
    let raf = 0;
    const frame = () => {
      raf = 0;
      refs.current.forEach((p, i) => {
        const next = refs.current[i + 1];
        if (!p || !next) return;
        const nr = next.getBoundingClientRect();
        const pr = p.getBoundingClientRect();
        const covered = Math.min(1, Math.max(0, 1 - (nr.top - pr.top) / pr.height));
        p.style.transform = `scale(${1 - covered * 0.04})`;
        p.style.filter = `brightness(${1 - covered * 0.04})`;
      });
    };
    const on = () => { if (!raf) raf = requestAnimationFrame(frame); };
    frame();
    window.addEventListener('scroll', on, { passive: true });
    return () => { window.removeEventListener('scroll', on); cancelAnimationFrame(raf); };
  }, []);

  return (
    <section className="how container" id="how">
      <div className="heading" data-reveal>
        <p className="t-label">What we build</p>
        <h2 className="t-h1">A website, and the system<br />that runs behind it.</h2>
        <p className="t-body">Pick one, or let us connect them so every enquiry gets answered, booked, paid and followed up.</p>
      </div>
      <div className="stack">
        {PANELS.map((p, i) => (
          <article key={p.tag} className="panel" style={{ top: 100 + i * 12 }} ref={(el) => { refs.current[i] = el; }}>
            <div className="text">
              <div>
                <p className="pill t-label">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.2" aria-hidden="true"><path d={p.icon} /></svg>
                  {p.tag}
                </p>
                <h3 className="t-h1 title">{p.title}</h3>
              </div>
              <div>
                <p className="t-body body">{p.body}</p>
                <Btn href={p.href}>{p.cta}</Btn>
              </div>
            </div>
            <div className={`media media-${p.media}`}>
              <Media kind={p.media} />
            </div>
          </article>
        ))}
      </div>
      <div className="center-btn"><Btn href="/services">See all services</Btn></div>
    </section>
  );
}
