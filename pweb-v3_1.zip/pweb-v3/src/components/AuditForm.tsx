'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useId, useState } from 'react';
import { ArrowUpRight, Check } from './ui';

type Status = 'idle' | 'sending' | 'done' | 'error';

/** Free website audit form. URL is required; "I don't have a website yet" sends people to /book instead. */
export function AuditForm({ compact = false, onDone }: { compact?: boolean; onDone?: () => void }) {
  const id = useId();
  const page = usePathname();
  const [noSite, setNoSite] = useState(false);
  const [status, setStatus] = useState<Status>('idle');

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setStatus('sending');
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: fd.get('name'), email: fd.get('email'), phone: fd.get('whatsapp') || undefined,
          website: fd.get('website'), company: fd.get('company'), pathway: 'website-audit', page,
        }),
      });
      if (!res.ok) throw new Error(String(res.status));
      setStatus('done');
      onDone?.();
    } catch {
      setStatus('error');
    }
  }

  if (status === 'done') {
    return (
      <div className="form-done" role="status">
        <span className="done-ico"><Check size={18} /></span>
        <p className="fd-title">Thanks, your audit is on its way.</p>
        <p className="fd-sub">We&apos;ll email you what to fix first.</p>
        <Link href="/book" className="form-btn">Book a call to go through it <ArrowUpRight /></Link>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className={`pw-form${compact ? ' compact' : ''}`}>
      <div className="row">
        <label className="sr" htmlFor={`${id}-n`}>Your name</label>
        <input id={`${id}-n`} name="name" required placeholder="Your name" autoComplete="name" />
        <label className="sr" htmlFor={`${id}-e`}>Email</label>
        <input id={`${id}-e`} name="email" type="email" required placeholder="Email" autoComplete="email" />
      </div>
      {!noSite && (
        <>
          <label className="sr" htmlFor={`${id}-w`}>Website URL</label>
          <input id={`${id}-w`} name="website" type="url" required placeholder="https://yourbusiness.com" inputMode="url" />
          {!compact && (
            <>
              <label className="sr" htmlFor={`${id}-wa`}>WhatsApp number (optional)</label>
              <input id={`${id}-wa`} name="whatsapp" type="tel" placeholder="WhatsApp number (optional)" autoComplete="tel" />
            </>
          )}
        </>
      )}
      <input name="company" tabIndex={-1} autoComplete="off" className="hp" aria-hidden="true" />
      <label className="check">
        <input type="checkbox" checked={noSite} onChange={(e) => setNoSite(e.target.checked)} />
        I don&apos;t have a website yet
      </label>
      {noSite ? (
        <div className="no-site">
          <p>No website yet? Book a call and we&apos;ll plan one with you.</p>
          <Link href="/book" className="form-btn">Book a free call <ArrowUpRight /></Link>
        </div>
      ) : (
        <button type="submit" className="form-btn" disabled={status === 'sending'}>
          {status === 'sending' ? 'Sending…' : 'Send me my free audit'} <ArrowUpRight />
        </button>
      )}
      {status === 'error' && <p role="alert" className="form-err">Something went wrong. Please try again, or message us on WhatsApp.</p>}
    </form>
  );
}
