import Image from 'next/image';
import { PortableText, type PortableTextComponents, type PortableTextBlock } from '@portabletext/react';

/** Renders a Sanity article body. Styling comes from the .prose class. */
const components: PortableTextComponents = {
  marks: {
    link: ({ value, children }) => {
      const href: string = value?.href || '#';
      const external = /^https?:\/\//.test(href) && !href.includes('pwebdigitals.com');
      return <a href={href} {...(external ? { target: '_blank', rel: 'noopener' } : {})}>{children}</a>;
    },
  },
  types: {
    image: ({ value }) => {
      if (!value?.url) return null;
      return (
        <figure>
          <Image src={`${value.url}?w=1600&auto=format`} alt={value.alt || ''} width={value.dims?.width || 1600} height={value.dims?.height || 900} sizes="(min-width: 760px) 720px, 92vw" />
          {value.caption && <figcaption>{value.caption}</figcaption>}
        </figure>
      );
    },
  },
};

export function PostBody({ body }: { body: PortableTextBlock[] }) {
  return <div className="prose"><PortableText value={body} components={components} /></div>;
}
