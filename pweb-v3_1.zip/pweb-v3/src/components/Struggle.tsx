'use client';

import { useEffect, useRef } from 'react';

const CARDS = [
  { t: 'Slow replies', d: 'A new enquiry waits hours for an answer, and the customer has already asked someone else.', icon: 'M12 7v5l3 2M21 12a9 9 0 11-18 0 9 9 0 0118 0z' },
  { t: 'Missed calls', d: 'You are busy with a client, the phone rings out, and that caller never tries again.', icon: 'M15 3h6v6M21 3l-7 7M5 4h3l2 5-2.5 1.5a11 11 0 005 5L14 13l5 2v3a2 2 0 01-2 2A15 15 0 013 6a2 2 0 012-2z' },
  { t: 'Booking in DMs', d: 'Dates and times go back and forth on WhatsApp until someone gives up.', icon: 'M8 2v4M16 2v4M3 9h18M5 4h14a2 2 0 012 2v13a2 2 0 01-2 2H5a2 2 0 01-2-2V6a2 2 0 012-2z' },
  { t: 'Chasing payments', d: 'Deposits and balances need reminders, screenshots and awkward follow-ups.', icon: 'M2 7h20v12H2zM2 11h20M6 15h4' },
  { t: 'Leads forgotten', d: 'Someone asked once, nobody followed up, and the sale quietly went cold.', icon: 'M4 6h16M4 12h10M4 18h6M17 15l4 4M21 15l-4 4' },
  { t: 'Hard to use on a phone', d: 'The site looks fine on a laptop, but most visitors are on a phone and leave.', icon: 'M7 2h10a2 2 0 012 2v16a2 2 0 01-2 2H7a2 2 0 01-2-2V4a2 2 0 012-2zM11 18h2' },
];

/** Cards orbit the pinned headline as you scroll. Front card is sharp and large; back cards shrink, blur and fade. */
export function Struggle() {
  const sec = useRef<HTMLElement>(null);
  const cards = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    let raf = 0;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const frame = () => {
      raf = 0;
      const el = sec.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      const total = el.offsetHeight - window.innerHeight;
      const p = Math.min(1, Math.max(0, -r.top / Math.max(1, total)));
      const enter = Math.min(1, Math.max(0, (window.innerHeight - r.top) / (window.innerHeight * 0.9)));
      const spread = reduce ? 1 : easeOut(enter);
      const mobile = window.innerWidth < 760;
      const rx = mobile ? window.innerWidth * 0.3 : Math.min(470, window.innerWidth * 0.33);
      const ry = mobile ? 190 : 250;
      cards.current.forEach((c, i) => {
        if (!c) return;
        const a = (i / CARDS.length) * Math.PI * 2 + Math.PI / 2 + p * Math.PI * 2;
        const depth = (Math.sin(a) + 1) / 2; // 1 = front (bottom), 0 = back (top)
        const x = Math.cos(a) * rx * spread;
        const y = Math.sin(a) * ry * spread + (mobile ? 90 : 70);
        const scale = (mobile ? 0.62 + 0.5 * depth : 0.7 + 0.7 * depth) * (0.25 + 0.75 * spread);
        c.style.transform = `translate(-50%, -50%) translate3d(${x}px, ${y}px, 0) scale(${scale})`;
        c.style.filter = `blur(${((1 - depth) * 10).toFixed(2)}px)`;
        c.style.opacity = String(((0.2 + 0.8 * depth) * spread).toFixed(3));
        c.style.zIndex = String(Math.round(depth * 100));
      });
    };
    const on = () => { if (!raf) raf = requestAnimationFrame(frame); };
    frame();
    window.addEventListener('scroll', on, { passive: true });
    window.addEventListener('resize', on);
    return () => { window.removeEventListener('scroll', on); window.removeEventListener('resize', on); cancelAnimationFrame(raf); };
  }, []);

  return (
    <section className="struggle" ref={sec}>
      <div className="orbit-stage">
        <div className="orbit-center">
          <p className="t-label">Why P-Web</p>
          <h2 className="t-h1">Most business websites look fine.<br />Then they do nothing.</h2>
        </div>
        {CARDS.map((c, i) => (
          <div key={c.t} className="orbit-card" ref={(el) => { cards.current[i] = el; }}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={c.icon} /></svg>
            <div>
              <h3 className="t-h3">{c.t}</h3>
              <p>{c.d}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function easeOut(t: number) { return 1 - Math.pow(1 - t, 3); }
