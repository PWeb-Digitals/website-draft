import Link from 'next/link';

/** Top of every inner page: label or breadcrumb, headline with the accent full stop, one-line intro, buttons. */
export function PageHero({
  label, title, sub, children, crumbs, left = false,
}: {
  label?: string;
  title: string;
  sub?: string;
  children?: React.ReactNode;
  crumbs?: { href: string; t: string }[];
  left?: boolean;
}) {
  const clean = title.replace(/[.!?]$/, '');
  const end = title.match(/[.!?]$/)?.[0] ?? '.';
  return (
    <section className={`page-hero${left ? ' left' : ''}`}>
      <div className="hero-backdrop" aria-hidden="true" />
      <div className="ph-copy container">
        {crumbs ? (
          <nav className="crumbs" aria-label="Breadcrumb">
            <Link href="/">Home</Link>
            {crumbs.map((c) => <span key={c.href}> / <Link href={c.href}>{c.t}</Link></span>)}
          </nav>
        ) : label ? <p className="t-label" data-reveal>{label}</p> : null}
        <h1 className="t-display" data-reveal>{clean}<span className="red-dot">{end}</span></h1>
        {sub && <p className="t-body lede" data-reveal>{sub}</p>}
        {children && <div className="ph-actions" data-reveal>{children}</div>}
      </div>
    </section>
  );
}

/** Small heading block used above sections on inner pages. */
export function SecIntro({ label, title, sub, center = false }: { label?: string; title: React.ReactNode; sub?: string; center?: boolean }) {
  return (
    <div className={`sec-intro${center ? ' center' : ''}`} data-reveal>
      {label && <p className="t-label">{label}</p>}
      <h2 className="t-h2">{title}</h2>
      {sub && <p className="t-body">{sub}</p>}
    </div>
  );
}
