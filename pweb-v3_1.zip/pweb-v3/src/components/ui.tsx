import Link from 'next/link';

export function ArrowRight({ className = 'arrow' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
export function ArrowUpRight({ className = 'arrow' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <path d="M5 11l6-6M6 5h5v5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
export function Chevron({ size = 12 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 12 12" fill="none" aria-hidden="true">
      <path d="M3 4.5l3 3 3-3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
export function Check({ size = 14 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 14 14" fill="none" aria-hidden="true">
      <path d="M2.5 7.2l2.8 2.8 6.2-6.4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
export function Star({ size = 22 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="var(--red)" aria-hidden="true">
      <path d="M12 2.5l2.9 6.1 6.6.8-4.9 4.6 1.3 6.5L12 17.3l-5.9 3.2 1.3-6.5L2.5 9.4l6.6-.8z" />
    </svg>
  );
}
export function Plus({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <path d="M8 3v10M3 8h10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

/** Four-point "+" marker drawn at the corners of framed areas. */
export function Marker({ pos }: { pos: 'tl' | 'tr' | 'bl' | 'br' }) {
  // Thin plus whose arms fade out, same construction as the reference marker.
  return (
    <svg className={`marker ${pos}`} viewBox="0 0 56 56" fill="none" aria-hidden="true">
      <defs>
        <linearGradient id="mk-h" x1="0" x2="56" y1="0" y2="0" gradientUnits="userSpaceOnUse"><stop stopColor="currentColor" stopOpacity="0" /><stop offset=".5" stopColor="currentColor" stopOpacity=".55" /><stop offset="1" stopColor="currentColor" stopOpacity="0" /></linearGradient>
        <linearGradient id="mk-v" x1="0" x2="0" y1="0" y2="56" gradientUnits="userSpaceOnUse"><stop stopColor="currentColor" stopOpacity="0" /><stop offset=".5" stopColor="currentColor" stopOpacity=".55" /><stop offset="1" stopColor="currentColor" stopOpacity="0" /></linearGradient>
      </defs>
      <path d="M0 28h56" stroke="url(#mk-h)" strokeWidth="1" />
      <path d="M28 0v56" stroke="url(#mk-v)" strokeWidth="1" />
      <path d="M22 28h12M28 22v12" stroke="currentColor" strokeWidth="2" />
    </svg>
  );
}

/** Button with the rolling label on hover. */
export function Btn({
  href, children, variant = 'light', size, icon = 'right', onClick, type,
}: { href?: string; children: React.ReactNode; variant?: 'light' | 'dark' | 'white'; size?: 'lg'; icon?: 'right' | 'upright' | 'none'; onClick?: () => void; type?: 'button' | 'submit' }) {
  const I = icon === 'upright' ? ArrowUpRight : icon === 'right' ? ArrowRight : null;
  const label = (
    <>
      {children}
      {I && <I />}
    </>
  );
  const inner = (
    <>
      <span className="btn-surface" aria-hidden="true" />
      <span className="btn-row">
        <span>{label}</span>
        <span aria-hidden="true">{label}</span>
      </span>
    </>
  );
  const cls = `btn btn-${variant}${size ? ` btn-${size}` : ''}`;
  if (href && /^https?:/.test(href)) return <a href={href} className={cls} target="_blank" rel="noopener">{inner}</a>;
  if (href) return <Link href={href} className={cls}>{inner}</Link>;
  return <button type={type || 'button'} onClick={onClick} className={cls}>{inner}</button>;
}

/** P-Web logo mark (the blue infinity P). */
export function LogoMark({ size = 28, white = false }: { size?: number; white?: boolean }) {
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img src={white ? '/images/brand/pweb-logo-white.png' : '/images/brand/pweb-logo-blue.png'} alt="" width={Math.round(size * 1.64)} height={size} style={{ height: size, width: 'auto' }} />
  );
}

export function Wordmark({ white = false }: { white?: boolean }) {
  return (
    <span className="wordmark">
      <LogoMark size={20} white={white} />
      <span>P-Web Digitals</span>
    </span>
  );
}

export function Ph({ label, dark = false, className = '', style }: { label: string; dark?: boolean; className?: string; style?: React.CSSProperties }) {
  return <div className={`ph${dark ? ' dark' : ''} ${className}`} style={style}><span>{label}</span></div>;
}

export function Avatar({ initials, size = 48, tone = 0 }: { initials: string; size?: number; tone?: number }) {
  const bgs = ['#d9d9d9', '#cfcfcf', '#bdbdbd', '#e6e6e6', '#c9c9c9'];
  return (
    <span className="avatar" style={{ width: size, height: size, background: bgs[tone % bgs.length], fontSize: size * 0.36 }} aria-hidden="true">
      {initials}
    </span>
  );
}

export function Caption({ name }: { name: string }) {
  return (
    <p className="caption t-label">
      <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><path d="M6 0l1.4 4.6L12 6l-4.6 1.4L6 12 4.6 7.4 0 6l4.6-1.4z" fill="var(--grey-1)" /></svg>
      <span>Section:</span> <a href="#">{name}</a>
    </p>
  );
}
