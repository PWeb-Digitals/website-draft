import { legalDocs } from '@/lib/legal';
import { PageHero } from './PageHero';

export function LegalPage({ slug }: { slug: string }) {
  const doc = legalDocs[slug];
  return (
    <>
      <PageHero crumbs={[{ href: `/${slug}`, t: doc.title }]} title={doc.title} sub={doc.summary} />
      <section className="section container" style={{ paddingTop: 0 }}>
        <article className="legal-card prose">
          <p className="updated">Last updated {doc.lastUpdated} · Effective {doc.effectiveDate} · Version {doc.version}</p>
          {doc.sections.map((s) => (
            <div key={s.heading}>
              <h2>{s.heading}</h2>
              <p>{s.content}</p>
            </div>
          ))}
          <h2>Contact</h2>
          <p>Questions about this policy? Email <a href="mailto:info@pwebdigitals.com">info@pwebdigitals.com</a>.</p>
        </article>
      </section>
    </>
  );
}
