'use client';

import { useEffect, useRef, useState } from 'react';

import { P, PlatformIcon, type Platform } from '@/lib/platforms';
import { Btn, LogoMark, Marker } from './ui';
import { FeatureGrid } from './FeatureGrid';

const ORB_TOOLS: Platform[] = [P.whatsapp, P.cal, P.paystack, P.n8n, P.gmail, P.stripe];
const ORBS = ORB_TOOLS.map((t) => ({ name: t.name, node: <PlatformIcon p={{ ...t, color: t.color.toLowerCase() === '#ffffff' ? '#0a0a0a' : t.color }} size={20} /> }));

export function Integration() {
  const [active, setActive] = useState(0);
  const [typed, setTyped] = useState('');
  const rot = useRef(0);
  const orbRefs = useRef<(HTMLSpanElement | null)[]>([]);
  const lineRefs = useRef<(SVGLineElement | null)[]>([]);
  const wrap = useRef<HTMLDivElement>(null);

  // slow rotation of the orbs around the hub
  useEffect(() => {
    let raf = 0;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const loop = () => {
      if (!reduce) rot.current += 0.0016;
      const w = wrap.current?.clientWidth || 528;
      const h = wrap.current?.clientHeight || 293;
      const cx = w / 2, cy = h / 2, rx = Math.min(200, w * 0.38), ry = h * 0.38;
      ORBS.forEach((_, i) => {
        const a = rot.current + (i / ORBS.length) * Math.PI * 2;
        const x = cx + Math.cos(a) * rx, y = cy + Math.sin(a) * ry;
        const o = orbRefs.current[i];
        if (o) o.style.transform = `translate(${x}px, ${y}px) translate(-50%, -50%)`;
        const l = lineRefs.current[i];
        if (l) { l.setAttribute('x1', String(cx)); l.setAttribute('y1', String(cy)); l.setAttribute('x2', String(x)); l.setAttribute('y2', String(y)); }
      });
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  // cycle the highlighted orb and type its name
  useEffect(() => {
    const t = setInterval(() => setActive((a) => (a + 1) % ORBS.length), 3200);
    return () => clearInterval(t);
  }, []);
  useEffect(() => {
    const name = ORBS[active].name;
    let i = 0;
    setTyped('');
    const t = setInterval(() => { i++; setTyped(name.slice(0, i)); if (i >= name.length) clearInterval(t); }, 55);
    return () => clearInterval(t);
  }, [active]);

  return (
    <>
      <section className="integration container" id="integration">
        <Marker pos="tl" /><Marker pos="tr" />
        <div className="copy" data-reveal>
          <p className="t-label">After someone finds you</p>
          <h2 className="t-h1">The system that<br />works while<br />you don&apos;t.</h2>
          <p className="t-body">We connect your website to WhatsApp, your calendar, payments and email, so the busy work runs on its own.</p>
          <Btn href="/crm-automation">See how it connects</Btn>
        </div>
        <figure className="visual">
          <div className="orbs" ref={wrap}>
            <svg className="orb-lines" aria-hidden="true">
              {ORBS.map((_, i) => (
                <line key={i} ref={(el) => { lineRefs.current[i] = el; }} className={i === active ? 'on' : ''} />
              ))}
            </svg>
            <span className="hub"><LogoMark size={22} /></span>
            {ORBS.map((o, i) => (
              <span key={o.name} className={`orb${i === active ? ' on' : ''}`} ref={(el) => { orbRefs.current[i] = el; }}>
                {o.node}
                {i === active && (
                  <>
                    <svg className="orb-ring" viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="30" /></svg>
                    <span className="orb-label"><i aria-hidden="true" />{typed}</span>
                  </>
                )}
              </span>
            ))}
          </div>
        </figure>
      </section>

      <FeatureGrid items="system" />
    </>
  );
}
