'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import { SERVICES } from '@/lib/services';
import { Btn, Chevron, Wordmark } from './ui';

const MORE = [
  { href: '/templates', title: 'Templates', desc: 'Working demo sites for your industry' },
  { href: '/blog', title: 'Blog', desc: 'Guides on websites, automation and growth' },
  { href: '/about', title: 'About', desc: 'Who builds your project' },
  { href: '/pricing', title: 'Pricing', desc: 'Clear prices before work starts' },
  { href: '/partner', title: 'Partner with us', desc: 'Agencies and co-building' },
];

function NavLink({ children }: { children: React.ReactNode }) {
  return (
    <span className="nav-roll">
      <span>{children}</span>
      <span aria-hidden="true">{children}</span>
    </span>
  );
}

export function Header() {
  const pathname = usePathname();
  const [open, setOpen] = useState<string | null>(null);
  const [mobile, setMobile] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [hidden, setHidden] = useState(false);

  // Like the reference: the header slides away while scrolling down and comes back on any scroll up.
  useEffect(() => {
    let last = window.scrollY;
    const on = () => {
      const y = window.scrollY;
      setScrolled(y > 40);
      if (Math.abs(y - last) > 4) { setHidden(y > last && y > 160); last = y; }
    };
    on();
    window.addEventListener('scroll', on, { passive: true });
    return () => window.removeEventListener('scroll', on);
  }, []);

  // close menus on navigation
  useEffect(() => { setOpen(null); setMobile(false); }, [pathname]);

  const menus = {
    Services: SERVICES.map((s) => ({ href: s.href, title: s.title, desc: s.desc })),
    More: MORE,
  } as const;

  return (
    <header className={`site-header${scrolled ? ' is-scrolled' : ''}${hidden && !open && !mobile ? ' is-hidden' : ''}`}>
      <div className="frame container">
        <aside className="offer-bar">
          <p className="offer t-body-s">
            <span className="group">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true"><circle cx="10" cy="10" r="7" stroke="var(--red)" strokeWidth="1.5" /><path d="M7 10.2l2 2 4-4.2" stroke="var(--red)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
              <span className="muted"><span className="em">Free website audit<span className="rest">:</span></span><span className="rest"> we check your site and email you what to fix first.</span></span>
            </span>
            <span className="group">
              <Link href="/audit" className="code"><span>Get my audit</span></Link>
            </span>
          </p>
        </aside>

        <div className="bar">
          <Link href="/" className="brand" aria-label="P-Web Digitals home"><Wordmark /></Link>

          <nav className="nav" aria-label="Main">
            {(Object.keys(menus) as (keyof typeof menus)[]).map((m) => (
              <div key={m} className="menu" onMouseEnter={() => setOpen(m)} onMouseLeave={() => setOpen(null)}>
                <button type="button" className="nav-link" aria-expanded={open === m} onClick={() => setOpen(open === m ? null : m)}>
                  <NavLink>{m} <Chevron /></NavLink>
                </button>
                <div className={`dropdown${open === m ? ' open' : ''}${m === 'Services' ? ' wide' : ''}`}>
                  <ul>
                    {menus[m].map((i) => (
                      <li key={i.href}><Link href={i.href}><span className="dd-ico" aria-hidden="true" /><span><strong>{i.title}</strong><small>{i.desc}</small></span></Link></li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
            <Link className="nav-link" href="/work"><NavLink>Work</NavLink></Link>
            <Link className="nav-link" href="/pricing"><NavLink>Pricing</NavLink></Link>
          </nav>

          <div className="actions">
            <Link className="nav-link signin" href="/contact"><NavLink>Contact</NavLink></Link>
            <Btn href="/book" variant="dark">Book a call</Btn>
            <button type="button" className="burger" aria-label={mobile ? 'Close menu' : 'Open menu'} aria-expanded={mobile} onClick={() => setMobile(!mobile)}>
              <span /><span />
            </button>
          </div>
        </div>

        <div className={`mobile-menu${mobile ? ' open' : ''}`}>
          <p className="mm-h">Services</p>
          {SERVICES.map((s) => <Link key={s.href} href={s.href}>{s.title}</Link>)}
          <p className="mm-h">More</p>
          {[{ href: '/work', title: 'Work' }, ...MORE, { href: '/contact', title: 'Contact' }].map((l) => <Link key={l.href} href={l.href}>{l.title}</Link>)}
          <div className="mm-cta"><Btn href="/book" variant="dark">Book a free call</Btn></div>
        </div>
      </div>
    </header>
  );
}
